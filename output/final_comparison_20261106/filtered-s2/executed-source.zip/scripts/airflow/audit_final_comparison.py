"""Check recorded evidence, including failures, before declaring the demo final."""
import argparse,json,hashlib
import numpy as np
from package_final_comparison import ROOT,OUT,DEST,source,load,write,audit_reuse

def main():
    p=argparse.ArgumentParser();p.add_argument('--allow-partial',action='store_true');a=p.parse_args()
    m=load(OUT/'comparison-results.json');checks=[];unfinished=[]
    for s in m['scenarios']:
        env=load(DEST/s['environment']);targets=np.asarray(env['targets'])
        initials=[]
        for row in s['runs']:
            ident=f"s{s['id']}-{row['method']}"
            if row['status'] not in ('Completed','Contact','Learning limit'):
                unfinished.append(ident)
                # Active recordings are atomically replaced by the runner;
                # verify their final immutable snapshot after completion.
                if a.allow_partial or 'record' not in row:continue
            path=source(s['id'],row['method']);r=load(path);z=r['summary']
            assert hashlib.sha256(path.read_bytes()).hexdigest()==row['source_sha256'],ident+' changed during audit'
            arr=np.asarray(r['samples']);ts=arr[:,0]
            assert np.all(np.isfinite(arr)) and np.all(np.diff(ts)>0),ident
            assert abs(ts[-1]-z['simulated_seconds'])<1e-7,ident
            assert np.max(np.abs(arr[:,5:7]))<=1.600001,ident+' actuator bound'
            assert abs(arr[-1,13]-row['final_clarity_deficit'])<1e-7,ident
            frame=r['clarity_frames'][0];q=np.asarray(frame['q'])
            assert q.shape==targets.shape and np.all((q>=0)&(q<=1)),ident
            np.testing.assert_allclose(np.maximum(targets-q,0).mean(),arr[0,13],atol=6e-7,rtol=0)
            initials.append((ident,arr[0,1:5],q))
            contact=z.get('contact')
            if contact:assert 0<=ts[-1]-contact['time_s']<=.200001,ident+' continued after contact'
            if row['reused']:
                audit_reuse(r)
            else:
                proto=load(path.with_name(r['id']+'-protocol.json'))
                assert proto['uncertainty_only'] and not proto['validated_handoff'],ident
                assert proto['initial_measurements']==0,ident+' prior survey'
                assert proto['rmse_threshold_m_s'] is None,ident+' oracle gate'
                assert proto['gp_profile']['prior_std_m_s']==1.8,ident+' prior changed'
                if row['status']=='Learning limit':
                    assert z['gate_time_s'] is None and z['simulated_seconds']>=proto['learning_limit_s'],ident+' stopped before declared learning limit'
            gate=z.get('gate_time_s')
            if row['method'] in ('global','proposed') and gate is not None:
                metric='task_vector_std_m_s' if row['method']=='proposed' else 'mean_variance'
                def sigma(f):return f[metric] if metric.startswith('task') else np.sqrt(2*f[metric])
                eligible=[f for f in r['belief_frames'] if f.get(metric) is not None and sigma(f)<=1.1+1e-10]
                assert eligible and abs(min(f['t'] for f in eligible)-gate)<1e-8,ident+' first threshold crossing differs'
            checks.append(dict(id=ident,outcome=row['status'],t=float(ts[-1]),
                first_visit=z['first_visit_s'],gate_s=gate,
                final_deficit=row['final_clarity_deficit'],observations=len(r['observations']),
                source_sha256=row['source_sha256']))
        for ident,x,q in initials[1:]:
            np.testing.assert_allclose(x,initials[0][1],atol=1e-7,rtol=0,err_msg=ident)
            np.testing.assert_allclose(q,initials[0][2],atol=1e-6,rtol=0,err_msg=ident)
    report=dict(final=len(checks)==15 and not unfinished,checked=checks,unfinished=unfinished,
        checks='Finite monotonically timed recordings; identical initial states/clarity within each scenario; actuator bounds; contact termination; displayed metrics from raw data; uncertainty-only first-crossing handoff and unknown prior; explicit historical reuse audit.')
    write(OUT/'final-integrity-audit.json',report);write(DEST/'final-integrity-audit.json',report)
    print(json.dumps(dict(final=report['final'],checked=len(checks),unfinished=unfinished)))
    if unfinished and not a.allow_partial:raise RuntimeError('Comparison still contains unfinished declared trials')

if __name__=='__main__':main()
