"""Immutable fixed-representation inducing updates with residual uncertainty.

Sequential variational likelihood updates, not exact conditioning of the full
predictive GP. The physical sample is never replaced after a measurement.
"""
import hashlib
from typing import NamedTuple

import jax
import jax.numpy as jnp
import jax.scipy.linalg as jsl
import numpy as np


def cholesky_downdate(root, vector):
    """Rank-one lower Cholesky downdate, O(M²), with explicit failure flag."""
    n = len(vector)
    def step(k, carry):
        L, x, valid = carry
        square = L[k, k]**2-x[k]**2
        good = (square > 0.) & jnp.isfinite(square) & (L[k, k] > 0.)
        r = jnp.sqrt(jnp.maximum(square, jnp.finfo(L.dtype).tiny))
        c, s = r/L[k, k], x[k]/L[k, k]
        column = (L[:, k]-s*x)/c
        mask = jnp.arange(n) > k
        L = L.at[:, k].set(jnp.where(mask, column, L[:, k])).at[k, k].set(r)
        x = jnp.where(mask, c*x-s*column, x)
        return L, x, valid & good
    L, _, valid = jax.lax.fori_loop(0, n, step, (root, vector, jnp.array(True)))
    return L, valid & jnp.all(jnp.isfinite(L))


def scalar_update(mean, root, design, centered_measurement, noise_variance):
    """Update q(inducing); conditional residual is deliberately absent here."""
    projected = root.T@design
    v = root@projected
    innovation_variance = noise_variance+jnp.dot(projected, projected)
    updated_mean = mean+v/innovation_variance*(centered_measurement-design@mean)
    vector = v/jnp.sqrt(innovation_variance)
    updated_root, valid = cholesky_downdate(root, vector)
    # One declared roundoff-scale retry, only after an unsuccessful downdate.
    # It is visible in retries, not a diagonal/zero covariance replacement.
    def retry(_):
        covariance = root@root.T-jnp.outer(vector, vector)
        jitter = 8*jnp.finfo(root.dtype).eps*jnp.maximum(jnp.max(jnp.diag(covariance)), 1.)
        L = jnp.linalg.cholesky((covariance+covariance.T)/2+jitter*jnp.eye(len(root)))
        return L, jnp.all(jnp.isfinite(L)), jnp.array(1)
    L, good, retries = jax.lax.cond(valid, lambda _: (updated_root, valid, jnp.array(0)), retry, None)
    good &= jnp.all(jnp.isfinite(updated_mean)) & (innovation_variance > 0.)
    return updated_mean, L, good, retries


class ShiftedBasis(NamedTuple):
    original: object
    prior_mean: jax.Array

    def evaluate(self, locations, coefficients):
        return self.prior_mean+self.original.evaluate(locations, coefficients)


class BeliefState(NamedTuple):
    representation: object
    kernel_root: jax.Array
    mean: jax.Array  # centered M×2 inducing means
    roots: jax.Array  # independent outputs, 2×M×M
    prior_mean: jax.Array
    noise_variance: jax.Array
    observation_count: jax.Array
    posterior_version: jax.Array
    last_sequence: jax.Array
    valid: jax.Array
    numerical_retries: jax.Array
    representation_id: jax.Array

    @property
    def basis(self):
        return ShiftedBasis(self.representation, self.prior_mean)

    @property
    def sample_shape(self):
        b = self.representation
        return (len(b.lengths)**2*2*len(b.frequencies)+len(b.support)+len(b.centers), 2)

    def design(self, locations):
        kernel = self.representation.kernel_centers(locations)
        return jsl.cho_solve((self.kernel_root, True), kernel.T).T

    def mean_at(self, locations):
        return self.prior_mean+self.design(locations)@self.mean

    def joint(self, locations):
        from .poam import attentive_kernel
        b = self.representation
        A = self.design(locations)
        K = attentive_kernel(b.parameters, jnp.atleast_2d(locations),
                              jnp.atleast_2d(locations), b.lengths)
        residual = K-A@b.kernel_centers(locations).T
        projected = jnp.einsum("nm,cmk->cnk", A, self.roots)
        covariance = residual[None]+jnp.einsum("cnk,cmk->cnm", projected, projected)
        return self.prior_mean+A@self.mean, (covariance+jnp.swapaxes(covariance, -1, -2))/2

    def predict(self, locations):
        A = self.design(locations)
        residual = jnp.exp(self.representation.parameters["log_amplitude"])-jnp.sum(
            A*self.representation.kernel_centers(locations), axis=1)
        projected = jnp.einsum("nm,cmk->cnk", A, self.roots)
        var = residual[None]+jnp.sum(projected**2, axis=-1)
        covariance = jnp.zeros((len(A), 2, 2)).at[:, 0, 0].set(var[0]).at[:, 1, 1].set(var[1])
        return self.prior_mean+A@self.mean, covariance

    def assimilate(self, position, observation, sequence, earned_time, available_time):
        """Consume an earned observation once. Duplicate/future samples are no-ops."""
        def update(b):
            a = b.design(position)[0]
            values = observation-b.prior_mean
            means, roots, valid, retries = jax.vmap(scalar_update)(
                b.mean.T, b.roots, jnp.broadcast_to(a, b.mean.T.shape), values, b.noise_variance)
            return b._replace(mean=means.T, roots=roots, observation_count=b.observation_count+1,
                posterior_version=b.posterior_version+1, last_sequence=sequence,
                valid=b.valid & jnp.all(valid), numerical_retries=b.numerical_retries+retries.sum())
        earned = (sequence > self.last_sequence) & (earned_time <= available_time) & self.valid
        return jax.lax.cond(earned, update, lambda b: b, self)

    def sample_coefficients(self, eps):
        b = self.representation
        m, ns = len(b.centers), len(b.support)
        nf = self.sample_shape[0]-m-ns
        prior, support, inducing = eps[:, :nf], eps[:, nf:nf+ns], eps[:, -m:]
        u = self.mean[None]+jnp.einsum("cij,njc->nic", self.roots, inducing)
        gz = jnp.einsum("mf,nfc->nmc", b.spectral_features(b.centers), prior)
        if ns:
            gs = jnp.einsum("sf,nfc->nsc", b.spectral_features(b.support), prior)
            vs = jnp.einsum("st,ntc->nsc", b.support_cholesky, support)
            correction = b.support_correction(vs-gs)
            gz += jnp.einsum("ms,nsc->nmc", b.kernel_support(b.centers), correction)
        else:
            correction = support
        inducing_correction = jax.vmap(lambda y: jsl.cho_solve((self.kernel_root, True), y))(u-gz)
        return jnp.concatenate((prior, correction, inducing_correction), axis=1)

    def sample_field(self, key, count):
        return self.sample_coefficients(jax.random.normal(key, (count, *self.sample_shape)))

    def inner_fields(self, eps):
        from .gp import InnerFields
        return InnerFields(self.basis, self.sample_coefficients(eps))


def from_poam(belief, *, prior_mean=(0., 0.), noise_covariance=None):
    """The supplied POAM must have been fitted to observations centered by prior_mean."""
    covariance = (np.eye(2)*float(belief.noise_std)**2 if noise_covariance is None
                  else np.asarray(noise_covariance))
    if covariance.shape != (2, 2) or not np.all(np.isfinite(covariance)):
        raise ValueError("Wind noise must be a finite 2×2 covariance")
    if np.any(covariance-np.diag(np.diag(covariance))):
        raise ValueError("Correlated component noise requires a joint inducing posterior; unsupported")
    if np.any(np.diag(covariance) <= 0):
        raise ValueError("Positive observation variances required")
    K = belief.kernel(belief.basis.centers, belief.basis.centers)
    kernel_root = jnp.linalg.cholesky((K+K.T)/2+1e-6*jnp.eye(len(K)))
    root = jnp.linalg.cholesky((belief.covariance+belief.covariance.T)/2)
    if not np.isfinite(root).all():
        raise ValueError("Invalid initial inducing covariance; no silent repair")
    digest = hashlib.sha256()
    for value in jax.tree.leaves(belief.basis):
        digest.update(np.asarray(value).tobytes())
    digest.update(np.asarray(prior_mean, dtype=np.float64).tobytes())
    representation_id = int.from_bytes(digest.digest()[:4], "little")
    return BeliefState(belief.basis, kernel_root, belief.mean, jnp.stack((root, root)),
        jnp.asarray(prior_mean, dtype=belief.mean.dtype), jnp.asarray(np.diag(covariance), dtype=belief.mean.dtype),
        jnp.array(0), jnp.array(0), jnp.array(-1), jnp.array(True), jnp.array(0),
        jnp.array(representation_id, dtype=jnp.uint32))


class CachedMean(NamedTuple):
    basis: object
    weights: jax.Array
    prior_mean: jax.Array

    def mean_at(self, locations):
        return self.prior_mean+self.basis.kernel_centers(locations)@self.weights


class ConstructionCache(NamedTuple):
    basis: object
    prior_at_inducing: jax.Array
    inducing_eps: jax.Array
    prior_mean: jax.Array
    representation_id: jax.Array

    def condition(self, belief):
        from .gp import InnerFields
        u = belief.mean[None]+jnp.einsum("cij,njc->nic", belief.roots, self.inducing_eps)
        coefficients = jax.vmap(lambda y: jsl.cho_solve((belief.kernel_root, True), y))(
            u-self.prior_at_inducing)
        weights = jsl.cho_solve((belief.kernel_root, True), belief.mean)
        matches = self.representation_id == belief.representation_id
        coefficients = jnp.where(matches, coefficients, jnp.nan)
        weights = jnp.where(matches, weights, jnp.nan)
        index = jnp.broadcast_to(jnp.arange(len(u))[:, None, None], (len(u), 1, 2))
        inner = InnerFields(ShiftedBasis(self.basis, self.prior_mean),
                            jnp.concatenate((index, coefficients), axis=1))
        return CachedMean(self.basis, weights, self.prior_mean), inner

    def tabulate(self, belief):
        """Fuse the same cached linear field before repeated filter queries.

        Interpolation is linear in grid values, so this adds no new spatial
        approximation. Update cost is paid at observation events, shared by all
        methods; tables and coefficients remain separate validated options.
        """
        from .cache import TableMean
        from .gp import InnerFields
        mean, fields = self.condition(belief)
        kernel = self.basis.kernel_grid
        values = self.basis.prior_fields+jnp.einsum(
            "yxm,nmc->nyxc", kernel, fields.coefficients[:, 1:])+self.prior_mean
        average = kernel@mean.weights+self.prior_mean
        return TableMean(self.basis.table, average), InnerFields(self.basis.table, values)


class DirectConstruction(NamedTuple):
    """Exact immutable Matheron terms; no spatial interpolation or projection."""
    eps: jax.Array
    prior_coefficients: jax.Array
    prior_at_inducing: jax.Array
    representation_id: jax.Array

    def condition(self, belief):
        from .gp import InnerFields
        m=len(belief.mean)
        u=belief.mean[None]+jnp.einsum('cij,njc->nic',belief.roots,self.eps[:,-m:])
        correction=jax.vmap(lambda y:jsl.cho_solve((belief.kernel_root,True),y))(
            u-self.prior_at_inducing)
        coefficients=self.prior_coefficients.at[:,-m:].set(correction)
        coefficients=jnp.where(self.representation_id==belief.representation_id,coefficients,jnp.nan)
        return belief,InnerFields(belief.basis,coefficients)

    def tabulate(self, belief):
        # Compatibility with the shared causal runner; deliberately no table.
        return self.condition(belief)


def build_construction_cache(belief, eps, cfg, spacing=.2):
    """Reuse the existing Catmull–Rom sampler and boundary convention.

    Only immutable prior draws and kernel columns are tabulated. Posterior
    updates change O(N_B M) coefficients, never the hidden physical-world table.
    """
    if getattr(cfg, 'field_evaluation', 'cached') == 'direct':
        m=len(belief.mean)
        coefficients=belief.sample_coefficients(eps).at[:,-m:].set(0.)
        prior=jax.vmap(lambda c:belief.representation.evaluate(
            belief.representation.centers,c))(coefficients)
        return DirectConstruction(eps,coefficients,prior,belief.representation_id)
    from ..quarter.environment import ExtendedTableBasis
    from .cache import DecoupledBasis
    low = jnp.array([-9., -6.])
    # Same fixed compact-detour support as the audited quarter implementation.
    nx, ny = round(18/spacing)+1, round(17.8/spacing)+1
    table = ExtendedTableBasis(low, jnp.full(2, spacing))
    yy, xx = jnp.meshgrid(jnp.arange(ny), jnp.arange(nx), indexing="ij")
    locations = low+jnp.c_[xx.ravel(), yy.ravel()]*spacing
    m = len(belief.mean)
    coefficients = belief.sample_coefficients(eps).at[:, -m:].set(0.)
    original = belief.representation
    prior_fields = jax.vmap(lambda c: original.evaluate(locations, c))(coefficients)
    gz = jax.vmap(lambda c: original.evaluate(original.centers, c))(coefficients)
    kernel = original.kernel_centers(locations).reshape(ny, nx, m)
    basis = DecoupledBasis(table, prior_fields.reshape(len(eps), ny, nx, 2), original, kernel)
    return ConstructionCache(basis, gz, eps[:, -m:], belief.prior_mean, belief.representation_id)
