"""Paired task-cost attribution for anticipated learning, not another reward.

Last axis indexes matched physical fields and observation-noise streams. Both
branches use the same policy parameters and initial state; only hypothetical
belief updates differ. Inputs are finite *raw task costs*. Contact/admissibility
must be reported separately, never converted to inf - inf or silently dropped.
"""

import numpy as np


def paired_learning_value(fixed_cost, learning_cost):
    fixed = np.asarray(fixed_cost, dtype=np.float64)
    learned = np.asarray(learning_cost, dtype=np.float64)
    if fixed.shape != learned.shape or fixed.ndim < 1 or fixed.shape[-1] == 0:
        raise ValueError("Expected matching nonempty arrays with physical fields on the last axis")
    if not (np.isfinite(fixed).all() and np.isfinite(learned).all()):
        raise ValueError("Use finite raw costs; report invalid trajectories separately")
    delta = fixed - learned
    helps, harms = delta > 0, delta < 0
    probability = helps.mean(axis=-1)
    benefit = np.maximum(delta, 0).mean(axis=-1)
    deterioration = np.maximum(-delta, 0).mean(axis=-1)
    magnitude = np.divide(benefit, probability, out=np.zeros_like(benefit), where=probability > 0)
    net = benefit - deterioration
    return {
        "delta": delta,
        "probability_improvement": probability,
        "conditional_improvement": magnitude,
        "probability_deterioration": harms.mean(axis=-1),
        "expected_positive_improvement": benefit,
        "expected_deterioration": deterioration,
        "net_value": net,
        "fixed_cost": fixed.mean(axis=-1),
        "learning_cost": learned.mean(axis=-1),
        "reconstructed_learning_cost": fixed.mean(axis=-1) - net,
        # Diagnostic ablation only: ignoring harm yields an optimistic objective.
        "positive_only_cost": fixed.mean(axis=-1) - benefit,
    }
