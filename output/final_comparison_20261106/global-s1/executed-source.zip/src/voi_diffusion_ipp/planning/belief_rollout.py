"""Shared disturbed-double-integrator runtime and causal forecasting core.

p_dot=v; v_dot=u+d(p). The GP estimates acceleration disturbance (m/s²).
The canonical clarity ODE evolves every cell at the attained position.
"""
from dataclasses import replace
from typing import NamedTuple

import jax
import jax.numpy as jnp

from .. import clarity, dynamics
from ..safety.rpcbf import design_policy, filter_control
from .route_policy import RECOVER, advance_events, policy_reference, update_progress


class RolloutState(NamedTuple):
    x: jax.Array
    q: jax.Array
    memory: object
    monitoring_cost: jax.Array
    constraint_cost: jax.Array
    status: jax.Array
    filter_call_count: jax.Array
    contact_count: jax.Array
    min_clearance: jax.Array
    max_slack: jax.Array
    slack_integral: jax.Array
    infeasible_count: jax.Array
    previous_control: jax.Array


def initial_state(x, q, memory, env):
    return RolloutState(x, q, memory, jnp.array(0.), jnp.array(0.), jnp.array(0), jnp.array(0),
        jnp.array(0), env.clearance(x), jnp.array(0.), jnp.array(0.), jnp.array(0), jnp.zeros(2))


def execution_step(state, now, policy, belief, construction, world, library, env, cfg, settings):
    """The only physical-world queries are in RK4 propagation (no sensor yet)."""
    h = cfg.execution_dt
    filter_cfg = replace(cfg, safety_margin=cfg.execution_margin)
    def live(s):
        memory = advance_events(s.x, s.q, belief, s.memory, policy, library, env, now,
                                cfg.horizon, settings)
        p, v, a = policy_reference(memory, library, now)
        nominal = (a+cfg.tracking_kp*(p-s.x[:2])+cfg.tracking_kv*(v-s.x[2:])
                   - belief.mean_at(s.x[:2])[0])
        nominal = jnp.where(memory.mode == RECOVER, design_policy(s.x, belief, filter_cfg), nominal)
        u, info = filter_control(s.x, nominal, belief, construction, env, filter_cfg)
        xn = dynamics.step(s.x, u, lambda p: world.at(p)[0], h)
        qn = clarity.step(s.q, s.x[:2], xn[:2], env.cells,
                          cfg.sensor_sigma, cfg.sensor_R, env.process_noise, h)
        finite = jnp.all(jnp.isfinite(jnp.r_[xn, qn, u, info.slack]))
        # Dense RK4 physical positions in the original analytic environment.
        # This retains the original collision diagnostic, without polygonizing
        # circles or inflating the point robot into a different vehicle.
        mids = jax.vmap(lambda t: dynamics.step(s.x, u, lambda p: world.at(p)[0], t))(
            h*jnp.array([.25, .5, .75, 1.]))
        gap = jnp.min(jax.vmap(env.clearance)(mids))
        contact = gap <= cfg.robot_radius
        status = jnp.where(~finite, 2, jnp.where(contact, 1, jnp.where(~memory.reference_valid, 3, 0)))
        good = status == 0
        reached = jnp.where(good, xn, jnp.r_[s.x[:2], jnp.zeros(2)])
        qn = jnp.where(good, qn, s.q/(1+h*env.process_noise*s.q))
        soft = cfg.violation_weight*jax.nn.relu(cfg.planning_clearance-gap)**2
        soft += cfg.speed_penalty*jax.nn.relu(jnp.linalg.norm(reached[2:])-cfg.speed_max)**2
        soft += cfg.jerk_penalty*jnp.sum(jax.nn.relu(jnp.abs((u-s.previous_control)/h)-cfg.jerk_limit)**2)
        cost = h*.5*(clarity.deficit(s.q, env.targets)+clarity.deficit(qn, env.targets))
        memory = update_progress(memory, reached, h, settings)
        return s._replace(x=reached, q=qn, memory=memory, monitoring_cost=s.monitoring_cost+cost,
            constraint_cost=s.constraint_cost+jnp.where(finite, h*soft, 0.), status=status,
            filter_call_count=s.filter_call_count+1, contact_count=s.contact_count+contact,
            min_clearance=jnp.minimum(s.min_clearance, gap-cfg.robot_radius),
            max_slack=jnp.maximum(s.max_slack, jnp.where(finite, info.slack, 0.)),
            slack_integral=s.slack_integral+h*jnp.where(finite, info.slack, 0.),
            infeasible_count=s.infeasible_count+(~info.feasible), previous_control=jnp.where(finite, u, 0.))
    def failed(s):
        # Full-horizon accounting, never a zero-cost truncated failure.
        qn = s.q/(1+h*env.process_noise*s.q)
        cost = h*.5*(clarity.deficit(s.q, env.targets)+clarity.deficit(qn, env.targets))
        return s._replace(q=qn, monitoring_cost=s.monitoring_cost+cost, previous_control=jnp.zeros(2))
    return jax.lax.cond(state.status == 0, live, failed, state)


def rollout_policy(state, policy, belief, construction, physical_world, library, env, cfg, settings):
    """One continuation per physical world, with no optimizer callback."""
    def tick(s, now):
        next_state = execution_step(s, now, policy, belief, construction, physical_world,
                                    library, env, cfg, settings)
        return next_state, next_state
    return jax.lax.scan(tick, state, jnp.arange(round(cfg.horizon/cfg.execution_dt))*cfg.execution_dt)


class AccessibleBelief(NamedTuple):
    posterior: object
    controller_mean: object

    def mean_at(self, positions):
        return self.controller_mean.mean_at(positions)

    def predict(self, positions):
        return self.posterior.predict(positions)


class LearningState(NamedTuple):
    execution: RolloutState
    belief: object
    controller_mean: object
    construction_fields: object


class LearningTrace(NamedTuple):
    x: jax.Array
    q: jax.Array
    u: jax.Array
    monitoring_cost: jax.Array
    constraint_cost: jax.Array
    mode: jax.Array
    route: jax.Array
    region: jax.Array
    departure_time: jax.Array
    reference_start_time: jax.Array
    posterior_version: jax.Array
    observation_sequence: jax.Array
    observation: jax.Array
    status: jax.Array
    min_clearance: jax.Array
    max_slack: jax.Array


def learning_state(execution, belief, construction_cache, tabulated=False):
    mean, fields = (construction_cache.tabulate(belief) if tabulated
                    else construction_cache.condition(belief))
    return LearningState(execution, belief, mean, fields)


def learning_step(state, tick, policy, physical_world, observation_noise, construction_cache,
                  library, env, cfg, settings, forecast_learning=True, route_adaptation=True,
                  decision_belief=None, time_offset=0., observations_enabled=True, tabulated=False):
    """Endpoint observation affects the *next* control interval, consumed once.

    Noise is indexed by absolute observation time slot. The simulated local
    accelerometer residual is y = v_dot - u + noise = d(p) + noise, in m/s².
    """
    now = time_offset+tick*cfg.execution_dt
    selector_belief = state.belief if route_adaptation else decision_belief
    accessible = AccessibleBelief(selector_belief, state.controller_mean)
    execution = execution_step(state.execution, now, policy, accessible,
        state.construction_fields, physical_world, library, env, cfg, settings)
    return observe_endpoint(state, execution, now, physical_world, observation_noise,
        construction_cache, cfg, forecast_learning, observations_enabled, tabulated)


def observe_endpoint(state, execution, now, physical_world, observation_noise,
                     construction_cache, cfg, forecast_learning=True,
                     observations_enabled=True, tabulated=False):
    """Shared earned-observation boundary for planar forecasts and the real plant."""
    period = round(cfg.observation_period/cfg.execution_dt)
    absolute_tick = jnp.rint(now/cfg.execution_dt).astype(jnp.int32)
    slot = (absolute_tick+1)//period-1
    observation_slot = ((absolute_tick+1) % period == 0) & observations_enabled
    earned = observation_slot & (execution.status == 0)
    def observe(_):
        noise = observation_noise[jnp.clip(slot, 0, len(observation_noise)-1)]
        noise = jnp.where((slot >= 0) & (slot < len(observation_noise)), noise, jnp.nan)
        measurement = physical_world.at(execution.x[:2])[0]+noise
        if forecast_learning:
            after = state.belief.assimilate(execution.x[:2], measurement, slot,
                                             now+cfg.execution_dt, now+cfg.execution_dt)
            mean, fields = (construction_cache.tabulate(after) if tabulated
                            else construction_cache.condition(after))
        else:
            after, mean, fields = state.belief, state.controller_mean, state.construction_fields
        return after, mean, fields, measurement
    def unchanged(_):
        return state.belief, state.controller_mean, state.construction_fields, jnp.full(2, jnp.nan)
    # The time-slot predicate is common/unbatched under world vmap. Keeping it
    # outside the alive mask prevents masked downdates on every integration tick.
    belief, mean, fields, measurement = jax.lax.cond(observation_slot,
        lambda _: jax.lax.cond(execution.status == 0, observe, unchanged, None), unchanged, None)
    execution = execution._replace(status=jnp.where(belief.valid, execution.status, 2))
    result = LearningState(execution, belief, mean, fields)
    trace = LearningTrace(execution.x, execution.q, execution.previous_control,
        execution.monitoring_cost, execution.constraint_cost, execution.memory.mode,
        execution.memory.active_directed_route, execution.memory.current_region,
        execution.memory.committed_departure_time, execution.memory.reference_start_time,
        belief.posterior_version, jnp.where(earned, slot, -1), measurement, execution.status,
        execution.min_clearance, execution.max_slack)
    return result, trace


def causal_rollout(state, policy, physical_world, observation_noise, construction_cache,
                   library, env, cfg, settings, forecast_learning=True, route_adaptation=True,
                   trace=False, time_offset=0., steps=None, observations_enabled=True, tabulated=False,
                   experimental_dynamic_steps=False):
    """One scan per hidden world; a fixed policy, never an inner optimizer."""
    count = round(cfg.horizon/cfg.execution_dt) if steps is None else steps
    initial_belief = state.belief
    def tick(s, i):
        next_state, log = learning_step(s, i, policy, physical_world, observation_noise,
            construction_cache, library, env, cfg, settings, forecast_learning,
            route_adaptation, initial_belief, time_offset, observations_enabled, tabulated)
        return next_state, log if trace else None
    if not trace and experimental_dynamic_steps:
        # A dynamic bound lets successive receding-horizon calls reuse one
        # compiled kernel. This optimization FAILED its paired numerical gate;
        # it remains isolated for diagnosis and is never enabled by default.
        return jax.lax.fori_loop(0, count, lambda i, s: tick(s, i)[0], state), None
    return jax.lax.scan(tick, state, jnp.arange(count))
