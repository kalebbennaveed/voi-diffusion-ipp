"""Compact causal route policy. No physical world or optimizer is accepted here.

37 bounded latent parameters, discrete root separate. The six geometric routes
are generated only from the original circles, bounds, and sensing anchors. Piecewise
quintics give deterministic C2 paths and an attained-state splice. Interior
knots retain tangent velocity; only monitoring anchors require a stop.
"""
import itertools
from typing import NamedTuple

import jax
import jax.numpy as jnp
import numpy as np

SENSE, TRAVERSE, RECOVER = 0, 1, 2
HOLD = 3
ROUTE_IDS = ("red_AB", "cyan_AB", "yellow_AB", "red_BA", "cyan_BA", "yellow_BA")
PARAMETER_NAMES = tuple(
    [f"{route}.{name}" for route in ROUTE_IDS for name in ("shape1", "shape2", "duration")]
    + [f"feature.{name}" for name in ("length", "headwind", "crosswind", "variance",
       "max_variance", "origin_deficit_length", "target_deficit_length",
       "remaining_time_variance", "deficit_difference_headwind")]
    + [f"bias.{direction}.{route}" for direction in ("AB", "BA") for route in ("red", "cyan")]
    + [f"dwell.{region}.{name}" for region in ("A", "B") for name in ("intercept", "own", "other")])


class RouteLibrary(NamedTuple):
    points: jax.Array
    normals: jax.Array
    phase: jax.Array
    duration_bounds: jax.Array
    segment_weights: jax.Array
    anchors: jax.Array
    cell_membership: jax.Array
    through_speed: jax.Array


def polynomial_peaks(points, times, through_speed=.5):
    """Exact polynomial extrema of a nominal reference, with no wind query.

    Unit-duration coefficients determine the time scaling: velocity / T and
    acceleration / T². These are reference bounds, not a replacement plant.
    """
    edge=np.diff(points,axis=0)/times[:,None]
    speed=np.linalg.norm(edge,axis=1);direction=edge/speed[:,None]
    middle=through_speed*(direction[:-1]+direction[1:])*np.minimum(speed[:-1],speed[1:])[:,None]
    velocities=np.vstack((np.zeros(2),middle,np.zeros(2)))
    peak_speed=peak_acceleration=0.
    def roots(coefficients):
        values=np.polynomial.polynomial.polyroots(coefficients)
        return [float(z.real) for z in values if abs(z.imag)<1e-9 and 0.<z.real<1.]
    for i,h in enumerate(times):
        delta=points[i+1]-points[i];v=velocities[i]*h;w=velocities[i+1]*h
        c3,c4,c5=10*delta-6*v-4*w,-15*delta+8*v+7*w,6*delta-3*v-3*w
        dv=np.array([v,np.zeros(2),3*c3,4*c4,5*c5])/h
        da=np.array([np.zeros(2),6*c3,12*c4,20*c5])/h**2
        stationary=sum((np.polynomial.polynomial.polymul(dv[:,axis],da[:,axis]) for axis in range(2)))
        for s in [0.,1.,*roots(stationary)]:
            peak_speed=max(peak_speed,np.linalg.norm(np.polynomial.polynomial.polyval(s,dv)))
        for axis in range(2):
            for s in [0.,1.,*roots(np.array([6*c3[axis],24*c4[axis],60*c5[axis]]))]:
                peak_acceleration=max(peak_acceleration,abs(np.polynomial.polynomial.polyval(s,da[:,axis])))
    return peak_speed,peak_acceleration


def route_library(env, cfg, settings):
    """Geometry-only central and two outer routes on the original circle map."""
    anchors = np.asarray((env.regions[:, :2]+env.regions[:, 2:])/2)
    a, b = anchors
    direction=(b-a)/np.linalg.norm(b-a)
    normal=np.array([-direction[1],direction[0]])
    fraction=np.linspace(0.,1.,6)
    # Same sin² outer-route family used by the original geometric seeds.
    # Larger offsets are determined by the circles and required clearance.
    separation=np.linalg.norm(np.asarray(env.obstacles)[0,:2]-np.asarray(env.obstacles)[1,:2])/2
    offset=separation+np.asarray(env.obstacles)[:,2].max()+.38
    paths=np.array([a+fraction[:,None]*(b-a)+h*np.sin(np.pi*fraction)[:,None]**2*normal
                    for h in (0.,offset,-offset-.15)],np.float32)
    paths = np.concatenate((paths, paths[:, ::-1]))
    lengths = np.linalg.norm(np.diff(paths, axis=1), axis=-1)
    if np.any(lengths <= 1e-6):
        raise ValueError("Route generator produced repeated waypoints")
    if not (lengths[0].sum() < lengths[1].sum() < lengths[2].sum()):
        raise ValueError("Geometry must represent short red, intermediate cyan, long yellow")
    # Minimum segment time from peak quintic speed/acceleration; duration bounds
    # are geometry/vehicle based, never measured from a hidden wind field.
    minimum = np.maximum(1.875*lengths/(.85*cfg.speed_max),
                         np.sqrt(5.774*lengths/(.8*cfg.umax)))
    weights = minimum/minimum.sum(axis=1, keepdims=True)
    durations = np.stack((minimum.sum(axis=1)*1.05, minimum.sum(axis=1)*1.55), axis=-1)
    through_speed=.2
    if cfg.route_timing=='analytic_polynomial':
        # Longer endpoint segments allow acceleration/deceleration. Interior
        # waypoints retain through velocity instead of nearly stopping there.
        weights=lengths*np.array([2.,1.,1.,1.,2.])[None]
        weights/=weights.sum(axis=1,keepdims=True)
        through_speed=.5
        peaks=np.array([polynomial_peaks(p,t,through_speed) for p,t in zip(paths,weights)])
        lower=np.maximum(peaks[:,0]/(.85*cfg.speed_max),np.sqrt(peaks[:,1]/(.8*cfg.umax)))
        durations=np.stack((1.05*lower,1.65*lower),axis=-1)
    elif cfg.route_timing!='original_segment_bounds':
        raise ValueError('Unknown reference timing contract')
    tangent = np.concatenate((paths[:, 1:2]-paths[:, :1], paths[:, 2:]-paths[:, :-2],
                              paths[:, -1:]-paths[:, -2:-1]), axis=1)
    tangent /= np.linalg.norm(tangent, axis=-1, keepdims=True)
    normals = np.stack((-tangent[..., 1], tangent[..., 0]), axis=-1)
    phase = np.c_[np.zeros(6), np.cumsum(lengths, axis=1)]/lengths.sum(axis=1)[:, None]
    cells = np.asarray(env.cells)
    membership = np.array([np.all((cells >= r[:2]) & (cells <= r[2:]), axis=1)
                           for r in np.asarray(env.regions)], np.float32)
    lib = RouteLibrary(*(jnp.asarray(v) for v in
        (paths, normals, phase, durations, weights, anchors, membership, through_speed)))
    # All segment sweeps, not just waypoints. Circle distance is 1-Lipschitz;
    # a .01 m sample gap with an extra .01 m margin certifies each straight edge.
    for route in paths:
        for p0, p1 in itertools.pairwise(route):
            points = np.linspace(p0, p1, int(np.ceil(np.linalg.norm(p1-p0)/.01))+1)
            clearance = jax.vmap(env.clearance)(jnp.c_[points, np.zeros_like(points)])
            if np.min(clearance) < settings.geometry_margin+.01:
                raise ValueError("Route generation failed inflated-obstacle clearance")
    return lib


class PolicyParameters(NamedTuple):
    shapes: jax.Array
    durations: jax.Array
    eta: jax.Array
    biases: jax.Array
    dwell: jax.Array


def decode(latent, library, settings):
    route = latent[:18].reshape(6, 3)
    bounds = library.duration_bounds
    return PolicyParameters(settings.deformation_scale*jnp.tanh(route[:, :2]),
        bounds[:, 0]+(bounds[:, 1]-bounds[:, 0])*jax.nn.sigmoid(route[:, 2]),
        latent[18:27], jnp.c_[latent[27:31].reshape(2, 2), jnp.zeros(2)],
        latent[31:37].reshape(2, 3))


def encode(policy, library, settings):
    fraction = ((policy.durations-library.duration_bounds[:, 0]) /
                (library.duration_bounds[:, 1]-library.duration_bounds[:, 0]))
    route = jnp.c_[jnp.arctanh(policy.shapes/settings.deformation_scale),
                   jnp.log(fraction)-jnp.log1p(-fraction)]
    return jnp.r_[route.ravel(), policy.eta, policy.biases[:, :2].ravel(), policy.dwell.ravel()]


def deformed_points(policy, library):
    basis = jnp.stack((jnp.sin(jnp.pi*library.phase), jnp.sin(2*jnp.pi*library.phase)), -1)
    offset = jnp.sum(basis*policy.shapes[:, None], axis=-1)
    offset = offset.at[:, 0].set(0.).at[:, -1].set(0.)
    return library.points+library.normals*offset[..., None]


def reference(points, segment_times, initial_velocity, elapsed, through_speed=.2):
    boundaries = jnp.cumsum(segment_times)
    index = jnp.minimum(jnp.sum(elapsed >= boundaries), len(segment_times)-1)
    start = jnp.r_[jnp.array([0.]), boundaries[:-1]][index]
    duration = segment_times[index]
    s = jnp.clip((elapsed-start)/duration, 0., 1.)
    p0, p1 = points[index], points[index+1]
    edge_velocity = (points[1:]-points[:-1])/segment_times[:, None]
    speeds = jnp.maximum(jnp.linalg.norm(edge_velocity, axis=1), 1e-9)
    directions = edge_velocity/speeds[:, None]
    interior = through_speed*(directions[:-1]+directions[1:])*jnp.minimum(speeds[:-1], speeds[1:])[:, None]
    velocities = jnp.concatenate((initial_velocity[None], interior, jnp.zeros((1, 2))))
    delta, v, w = p1-p0, velocities[index]*duration, velocities[index+1]*duration
    c3, c4, c5 = 10*delta-6*v-4*w, -15*delta+8*v+7*w, 6*delta-3*v-3*w
    position = p0+v*s+c3*s**3+c4*s**4+c5*s**5
    velocity = (v+3*c3*s**2+4*c4*s**3+5*c5*s**4)/duration
    acceleration = (6*c3*s+12*c4*s**2+20*c5*s**3)/duration**2
    return position, velocity, acceleration


def regional_deficits(q, env, library):
    return (library.cell_membership@jnp.maximum(env.targets-q, 0.) /
            jnp.sum(library.cell_membership, axis=1))


def route_features(policy, library, belief, deficits, region, remaining, horizon, settings):
    points = deformed_points(policy, library)
    indices = region*3+jnp.arange(3)
    fractions = jnp.linspace(0., 1., settings.feature_points)
    def one(route):
        path = points[route]
        edges = path[1:]-path[:-1]
        distances = jnp.linalg.norm(edges, axis=1)
        cumulative = jnp.r_[jnp.array([0.]), jnp.cumsum(distances)]
        s = fractions*cumulative[-1]
        ii = jnp.minimum(jnp.sum(s[:, None] >= cumulative[None, 1:], axis=1), len(edges)-1)
        f = (s-cumulative[ii])/distances[ii]
        query = path[ii]+f[:, None]*edges[ii]
        tangent = edges[ii]/distances[ii, None]
        normal = jnp.stack((-tangent[:, 1], tangent[:, 0]), -1)
        mu, covariance = belief.predict(query)
        L = cumulative[-1]/settings.length_scale
        head = -jnp.mean(jnp.sum(tangent*mu, axis=-1))/settings.wind_scale
        cross = jnp.mean(jnp.sum(normal*mu, axis=-1)**2)/settings.wind_scale**2
        variance = jnp.trace(covariance, axis1=-2, axis2=-1)/settings.wind_scale**2
        own, other = deficits[region], deficits[1-region]
        return jnp.array([L, head, cross, variance.mean(), variance.max(), own*L,
                          other*L, remaining/horizon*variance.mean(), (other-own)*head])
    return jax.vmap(one)(indices)


def select_route(policy, library, belief, deficits, region, remaining, horizon, settings):
    features = route_features(policy, library, belief, deficits, region, remaining, horizon, settings)
    scores = features@policy.eta+policy.biases[region]
    choice = jnp.argmin(scores)  # Stored red/cyan/yellow order breaks exact ties.
    return region*3+choice, jnp.sum(scores == scores[choice]) > 1


class ExecutionMemory(NamedTuple):
    mode: jax.Array
    current_region: jax.Array
    active_directed_route: jax.Array
    reference_points: jax.Array
    segment_times: jax.Array
    initial_velocity: jax.Array
    reference_start_time: jax.Array
    reference_progress: jax.Array
    origin_region: jax.Array
    target_region: jax.Array
    committed_departure_time: jax.Array
    committed_first_route: jax.Array
    first_route_consumed: jax.Array
    arrival_flag: jax.Array
    no_progress_elapsed: jax.Array
    recovery_attempted: jax.Array
    hold: jax.Array
    reference_valid: jax.Array
    selector_tie: jax.Array
    sensing_start_time: jax.Array


def dwell_time(policy, deficits, region, settings):
    inputs = jnp.array([1., deficits[region], deficits[1-region]])
    return settings.dwell_min+(settings.dwell_max-settings.dwell_min)*jax.nn.sigmoid(
        policy.dwell[region]@inputs)


def initial_memory(policy, library, deficits, root, region, now, settings):
    return ExecutionMemory(jnp.array(SENSE), jnp.array(region), jnp.array(-1),
        jnp.tile(library.anchors[region], (6, 1)), jnp.ones(5), jnp.zeros(2), jnp.array(now),
        jnp.array(0.), jnp.array(region), jnp.array(1-region),
        now+dwell_time(policy, deficits, region, settings), jnp.array(root),
        jnp.array(False), jnp.array(False), jnp.array(0.), jnp.array(False),
        jnp.array(root == HOLD), jnp.array(True), jnp.array(False), jnp.array(now))


def attained_arrival(x, target, settings):
    return ((jnp.linalg.norm(x[:2]-target) <= settings.arrival_radius) &
            (jnp.linalg.norm(x[2:]) <= settings.arrival_speed))


def advance_events(x, q, belief, memory, policy, library, env, now, horizon, settings):
    """One event per timestamp. Committed times survive every policy replan."""
    deficits = regional_deficits(q, env, library)
    def sensing(m):
        def depart(m):
            selected, tie = select_route(policy, library, belief, deficits, m.current_region,
                                         jnp.maximum(horizon-now, 0.), horizon, settings)
            route = jnp.where(m.first_route_consumed, selected,
                              m.current_region*3+jnp.minimum(m.committed_first_route, 2))
            points = deformed_points(policy, library)[route].at[0].set(x[:2])
            times = library.segment_weights[route]*policy.durations[route]
            # Splice is sampled more densely when velocity is large. Fixed
            # 129 samples and a conservative speed-derived covering radius.
            t = jnp.linspace(0., times[0], 129)
            samples = jax.vmap(lambda tau: reference(points, times, x[2:], tau,library.through_speed)[0])(t)
            clearance = jax.vmap(lambda p: env.clearance(jnp.r_[p, jnp.zeros(2)]))(samples)
            delta = jnp.linalg.norm(points[1]-points[0])
            speed_bound = jnp.where(library.through_speed>.2,5.,1.875)*delta/times[0]+16*jnp.linalg.norm(x[2:])
            valid = jnp.min(clearance) >= settings.geometry_margin+speed_bound*times[0]/256
            return m._replace(mode=jnp.where(valid, TRAVERSE, RECOVER),
                active_directed_route=route, reference_points=points, segment_times=times,
                initial_velocity=x[2:], reference_start_time=now, reference_progress=jnp.array(0.),
                origin_region=m.current_region, target_region=1-m.current_region,
                first_route_consumed=jnp.array(True), arrival_flag=jnp.array(False),
                no_progress_elapsed=jnp.array(0.), reference_valid=valid, selector_tie=tie,
                recovery_attempted=~valid)
        return jax.lax.cond((now >= m.committed_departure_time) & ~m.hold, depart, lambda m: m, m)
    def traverse(m):
        arrived = attained_arrival(x, library.anchors[m.target_region], settings)
        def arrive(m):
            return m._replace(mode=jnp.array(SENSE), current_region=m.target_region,
                arrival_flag=jnp.array(True), sensing_start_time=now, committed_departure_time=now+dwell_time(
                    policy, deficits, m.target_region, settings), no_progress_elapsed=jnp.array(0.))
        def keep(m):
            timeout = ((now-m.reference_start_time > settings.traversal_timeout_factor*jnp.sum(
                m.segment_times)+settings.traversal_timeout_extra) |
                (m.no_progress_elapsed >= settings.no_progress_timeout))
            return m._replace(mode=jnp.where(timeout, RECOVER, TRAVERSE),
                              recovery_attempted=m.recovery_attempted | timeout)
        return jax.lax.cond(arrived, arrive, keep, m)
    return jax.lax.switch(memory.mode, (sensing, traverse, lambda m: m), memory)


def update_progress(memory, x, dt, settings):
    # Furthest attained projection onto a polyline; no nominal-time progress.
    p = memory.reference_points
    edges = p[1:]-p[:-1]
    length = jnp.linalg.norm(edges, axis=1)
    f = jnp.clip(jnp.sum((x[:2]-p[:-1])*edges, axis=1)/jnp.maximum(length**2, 1e-12), 0., 1.)
    projected = p[:-1]+f[:, None]*edges
    index = jnp.argmin(jnp.linalg.norm(projected-x[:2], axis=1))
    cumulative = jnp.r_[jnp.array([0.]), jnp.cumsum(length)]
    progress = cumulative[index]+f[index]*length[index]
    improved = progress > memory.reference_progress+settings.progress_hysteresis
    return memory._replace(reference_progress=jnp.where(improved, progress, memory.reference_progress),
        no_progress_elapsed=jnp.where(memory.mode == TRAVERSE,
                                      jnp.where(improved, 0., memory.no_progress_elapsed+dt), 0.))


def policy_reference(memory, library, now):
    active = reference(memory.reference_points, memory.segment_times, memory.initial_velocity,
                       now-memory.reference_start_time,library.through_speed)
    # Shared geometry-defined sweep, sensed only through C_j at the attained
    # state. A complete sin^3 cycle returns to the anchor at rest. Dwell below
    # four seconds may end mid-cycle; departure splices the attained p and v.
    duration = jnp.maximum(memory.committed_departure_time-memory.sensing_start_time, 4.)
    elapsed = jnp.maximum(now-memory.sensing_start_time, 0.)
    phase = jnp.where(memory.hold, jnp.mod(elapsed, duration), jnp.minimum(elapsed, duration))/duration
    angle = 2*jnp.pi*phase
    ss, cc = jnp.sin(angle), jnp.cos(angle)
    omega = 2*jnp.pi/duration
    sweep = jnp.array([.25, .20])
    sensing = (library.anchors[memory.current_region]+sweep*ss**3,
               sweep*3*omega*ss**2*cc,
               sweep*3*omega**2*(2*ss*cc**2-ss**3))
    return jax.tree.map(lambda a, b: jnp.where(memory.mode == TRAVERSE, a, b), active, sensing)
