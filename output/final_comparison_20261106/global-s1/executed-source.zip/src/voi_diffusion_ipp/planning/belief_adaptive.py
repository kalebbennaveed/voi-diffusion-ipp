"""Bounded discrete-root searches using the existing expected-cost MBD core.

Search and fresh selection receive separate evaluation functions. Neither can
access the held-out physical episode. Budget accounting is outside rollout scans.
"""
import time
from dataclasses import dataclass, replace

import jax
import jax.numpy as jnp
import numpy as np

from ..quarter.mbd_core import search
from .route_policy import HOLD, SENSE, decode


@dataclass(frozen=True)
class SearchBudget:
    total_policy_evaluations: int = 64
    performance_worlds: int = 8
    shortlist: int = 6
    validation_worlds: int = 16
    levels: int = 2
    proposals: int = 7
    seed_count: int = 3

    def __post_init__(self):
        if min(self.total_policy_evaluations, self.performance_worlds, self.shortlist,
               self.validation_worlds, self.levels, self.proposals, self.seed_count) < 1:
            raise ValueError("All search budgets must be positive")
        if self.seed_count != 3:
            raise ValueError("Three declared initializations are implemented")

    @property
    def per_root(self):
        # Existing search scores its final mean but does not expose that score.
        # An explicit, counted re-score exports it for cross-root shortlisting.
        return self.seed_count+1+self.levels*self.proposals+2


def stream_keys(seed, cycle=0):
    """Named, disjoint streams; common across methods and candidate policies."""
    tags = {"real_field": 1001, "real_noise": 1002, "performance_fields": 2001,
            "performance_noise": 2002, "construction": 3001, "diffusion": 4001,
            "validation_fields": 5001, "validation_noise": 5002, "held_out": 6001}
    base = jax.random.PRNGKey(seed)
    return {name: jax.random.fold_in(jax.random.fold_in(base, tag), cycle)
            for name, tag in tags.items()}


def incumbents(previous):
    # Previous continuation is added by the existing search implementation.
    simple = jnp.zeros(37).at[18].set(.2)
    headwind = simple.at[19].set(1.)
    directional = simple.at[27].set(-1.).at[29].set(1.)
    return jnp.stack((simple, headwind, directional))


def root_memory(memory, root):
    """Only a sensing decision may commit a new root; never move its timer."""
    legal = memory.mode == SENSE
    return memory._replace(committed_first_route=jnp.where(legal, root, memory.committed_first_route),
        first_route_consumed=jnp.where(legal, False, memory.first_route_consumed),
        hold=jnp.where(legal, root == HOLD, memory.hold))


def solve(search_evaluate, validation_evaluate, previous, key, cfg, budget=None,
          *, sensing=True, root_search=None, progress=None):
    """Each evaluator(root, theta) returns all raw per-world total costs.

    Ineligible world executions must be returned as +inf. Retained finalists
    have already been evaluated on the search bank; all final selection uses a
    new common bank. No clamping or uncounted retry adds a candidate.
    """
    budget = SearchBudget() if budget is None else budget
    roots = (0, 1, 2) if sensing else (-1,)
    hold_count = int(sensing)
    requested = len(roots)*budget.per_root+hold_count
    if requested > budget.total_policy_evaluations:
        raise ValueError(f"Search requires {requested} evaluations, cap is {budget.total_policy_evaluations}")
    settings = replace(cfg, iterations=budget.levels, proposals=budget.proposals,
        batch_size=1, initialization="modes", multimode=False, latent_bound=3.,
        worlds=budget.performance_worlds, validation_worlds=budget.validation_worlds)
    initial = incumbents(previous)
    @jax.jit
    def one_root(root, root_key):
        return search(lambda theta: search_evaluate(root, theta), initial, previous, root_key,
                      settings, 1., 0., jnp.array(False))
    if root_search is not None:
        one_root = root_search
    records, candidates = [], []
    started = time.perf_counter()
    for root in roots:
        if progress: progress({'event':'root_started','root':root})
        result = one_root(jnp.array(root), jax.random.fold_in(key, root+1))
        result.final.block_until_ready()
        if int(result.evaluations)+1 != budget.per_root:
            raise RuntimeError("Existing MBD evaluation count disagrees with hard budget")
        # Recover scores from already evaluated seeds/proposals/final means.
        all_parameters = np.concatenate((np.asarray(result.initial_parameters),
            np.asarray(result.samples).reshape(-1, 37), np.asarray(result.final)[None]))
        initial_costs = np.asarray(result.initial_field_costs).mean(axis=1)
        sample_costs = np.asarray(result.field_costs).mean(axis=-1).ravel()
        final_costs = np.asarray(search_evaluate(jnp.array(root), result.final))
        available = np.r_[initial_costs, sample_costs, final_costs.mean()]
        for rank, (theta, index) in enumerate(zip(np.asarray(result.finalists), np.asarray(result.finalist_indices))):
            if np.all(np.isfinite(theta)) and np.all(np.abs(theta) <= settings.latent_bound):
                score = float(available[index])
                candidates.append((root, theta.copy(), score, int(index), rank))
        records.append({"root": root, "evaluations": int(result.evaluations)+1,
            "initial_cost": float(result.initial_cost), "trace": np.asarray(result.trace),
            "final_mean": np.asarray(result.final), "final_field_costs": final_costs,
            "evaluated_parameters": all_parameters, "extra_final_mean_rescores": 1})
        if progress: progress({'event':'root_completed','root':root,'elapsed_seconds':time.perf_counter()-started,
                               'finite_candidates':int(np.isfinite(available).sum())})
    if sensing:
        hold_costs = np.asarray(search_evaluate(jnp.array(HOLD), previous))
        if len(hold_costs) != budget.performance_worlds:
            raise ValueError("Search world count disagrees with budget")
        candidates.append((HOLD, np.asarray(previous), float(hold_costs.mean()), -1, 0))
    search_seconds = time.perf_counter()-started
    unique = []
    for candidate in sorted(candidates, key=lambda c: (c[2], c[0], c[4])):
        root, theta, score, index, rank = candidate
        if not np.isfinite(score):
            continue
        if any(root == old[0] and np.array_equal(theta, old[1]) for old in unique):
            continue
        unique.append(candidate)
        if len(unique) == budget.shortlist:
            break
    if not unique:
        return {"valid": False, "reason": "No finite evaluated incumbent", "policy_evaluations": requested,
                "validation_evaluations": 0, "physical_rollouts": requested*budget.performance_worlds,
                "search_seconds": search_seconds, "search": records}
    started = time.perf_counter()
    validation = []
    for root, theta, *_ in unique:
        values = np.asarray(validation_evaluate(jnp.array(root), jnp.asarray(theta)))
        if values.shape != (budget.validation_worlds,):
            raise ValueError("Fresh validation world count disagrees with budget")
        validation.append(values)
    validation = np.array(validation)
    scores = np.where(np.isfinite(validation).all(axis=1), validation.mean(axis=1), np.inf)
    chosen = int(np.argmin(scores))
    return {"valid": bool(np.isfinite(scores[chosen])), "root": unique[chosen][0],
        "theta": unique[chosen][1], "validation_cost": float(scores[chosen]),
        "validation_field_costs": validation, "shortlist": unique,
        "policy_evaluations": requested, "validation_evaluations": len(unique),
        "physical_rollouts": requested*budget.performance_worlds+len(unique)*budget.validation_worlds,
        "search_seconds": search_seconds, "validation_seconds": time.perf_counter()-started,
        "search": records}


def evaluator(start, cache, fields, observation_noise, library, env, cfg, settings, *, learning,
              tabulated=False, time_offset=0., steps=None, route_adaptation=True,
              observations_enabled=True):
    from ..wind.gp import WorldField
    from .belief_rollout import causal_rollout
    @jax.jit
    def values(root, latent):
        policy = decode(latent, library, settings)
        memory = root_memory(start.execution.memory, root)
        current = start._replace(execution=start.execution._replace(memory=memory))
        def world(coefficients, noise):
            end, _ = causal_rollout(current, policy, WorldField(fields.basis, coefficients),
                noise, cache, library, env, cfg, settings, forecast_learning=learning,
                tabulated=tabulated, time_offset=time_offset, steps=steps,
                route_adaptation=route_adaptation, observations_enabled=observations_enabled)
            cost = (end.execution.monitoring_cost+end.execution.constraint_cost
                    -start.execution.monitoring_cost-start.execution.constraint_cost)
            eligible = (end.execution.status == 0) & end.belief.valid
            return jnp.where(eligible, cost, jnp.inf)
        return jax.vmap(world)(fields.coefficients, observation_noise)
    return values


def reusable_kernels(cache, library, env, cfg, settings, budget, *, learning,
                     route_adaptation=True, work_log=None):
    """EXPERIMENTAL: failed the Stage-6 compilation-reuse numerical gate.

    Retained only to reproduce/diagnose that failure; normal mission drivers
    must not enable this path. No tolerance or scientific setting was relaxed.
    """
    from ..wind.gp import WorldField
    from .belief_rollout import causal_rollout
    search_cfg = replace(cfg, iterations=budget.levels, proposals=budget.proposals,
        batch_size=1, initialization="modes", multimode=False, latent_bound=3.,
        worlds=budget.performance_worlds, validation_worlds=budget.validation_worlds)
    def record_work(root, calls, updates, steps):
        work_log.append({"root": int(root), "worlds": len(calls),
            "logical_filter_calls": int(np.asarray(calls).sum()),
            "hypothetical_updates": int(np.asarray(updates).sum()),
            "propagated_world_intervals": int(len(calls)*steps)})
    @jax.jit
    def values(start, fields, observation_noise, root, latent, now, steps):
        policy = decode(latent, library, settings)
        current = start._replace(execution=start.execution._replace(
            memory=root_memory(start.execution.memory, root)))
        def world(coefficients, noise):
            end, _ = causal_rollout(current, policy, WorldField(fields.basis, coefficients),
                noise, cache, library, env, cfg, settings, forecast_learning=learning,
                tabulated=True, time_offset=now, steps=steps, route_adaptation=route_adaptation,
                experimental_dynamic_steps=True)
            cost = (end.execution.monitoring_cost+end.execution.constraint_cost
                    -start.execution.monitoring_cost-start.execution.constraint_cost)
            return (jnp.where((end.execution.status == 0) & end.belief.valid, cost, jnp.inf),
                end.execution.filter_call_count-start.execution.filter_call_count,
                end.belief.observation_count-start.belief.observation_count)
        costs, calls, updates = jax.vmap(world)(fields.coefficients, observation_noise)
        if work_log is not None:
            jax.debug.callback(record_work, root, calls, updates, steps, ordered=True)
        return costs
    @jax.jit
    def root_search(start, fields, observation_noise, previous, root, key, now, steps):
        return search(lambda latent: values(start, fields, observation_noise, root, latent, now, steps),
            incumbents(previous), previous, key, search_cfg, 1., 0., jnp.array(False))
    return values, root_search
