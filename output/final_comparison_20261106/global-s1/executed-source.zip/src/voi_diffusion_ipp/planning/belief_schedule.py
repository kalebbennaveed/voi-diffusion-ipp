"""Host-side plan activation; no speculative belief or vehicle state is installed."""
from dataclasses import dataclass

import jax.numpy as jnp
import numpy as np

from .belief_adaptive import root_memory
from .route_policy import SENSE


@dataclass(frozen=True)
class Snapshot:
    time: float
    mode: int
    region: int
    active_route: int
    reference_start: float
    departure: float
    posterior_version: int


def snapshot(learning, now):
    m = learning.execution.memory
    return Snapshot(float(now), int(m.mode), int(m.current_region),
                    int(m.active_directed_route), float(m.reference_start_time),
                    float(m.committed_departure_time), int(learning.belief.posterior_version))


def activate(current, incumbent, plan, captured, now, *, deadline_seconds=None):
    """Retain attained state, real posterior, and commitment clocks on every path.

    During traversal, new coefficients only govern decisions after arrival; the
    active reference stays attached. While sensing, departure constructs a new
    reference from the attained position/velocity. A changed mode, route, or
    arrival/departure epoch makes a delayed result incompatible.
    """
    arrived = snapshot(current, now)
    reason = "accepted"
    if now < captured.time:
        raise ValueError("Activation cannot precede the planning snapshot")
    if deadline_seconds is not None and now-captured.time > deadline_seconds+1e-8:
        reason = "missed_deadline"
    elif int(current.execution.status) != 0:
        reason = "execution_failed"
    elif not plan.get("valid", False):
        reason = "no_eligible_candidate"
    elif (captured.mode, captured.region, captured.active_route, captured.reference_start,
          captured.departure) != (arrived.mode, arrived.region, arrived.active_route,
                                arrived.reference_start, arrived.departure):
        reason = "stale_mode_route_or_commitment"
    else:
        theta = np.asarray(plan.get("theta", []))
        root = plan.get("root")
        if theta.shape != (37,) or not np.isfinite(theta).all() or np.any(np.abs(theta) > 3.):
            reason = "invalid_parameters"
        elif root not in ((0, 1, 2, 3) if arrived.mode == SENSE else (-1,)):
            reason = "incompatible_root"
    accepted = reason == "accepted"
    if accepted:
        memory = root_memory(current.execution.memory, jnp.array(plan["root"]))
        current = current._replace(execution=current.execution._replace(memory=memory))
        incumbent = jnp.asarray(plan["theta"])
    record = {"accepted": accepted, "reason": reason, "snapshot_time": captured.time,
        "activation_time": float(now), "snapshot_posterior_version": captured.posterior_version,
        "activation_posterior_version": arrived.posterior_version,
        "latency_seconds": float(now-captured.time)}
    return current, incumbent, record
