"""Double-integrator execution using exactly the forecasting runtime.

The physical state is [px, py, vx, vy]. State, clarity, posterior, active
reference and sensing clocks persist across every replanning boundary.
"""
import jax
import jax.numpy as jnp

from .belief_rollout import learning_step


def execution_runner(physical_world, cache, library, env, cfg, settings, steps,
                     *, observations_enabled=True, route_adaptation=True):
    if cfg.linear_drag != 0.:
        raise ValueError("Double-integrator execution requires zero linear drag")

    @jax.jit
    def run(state, policy, noise, time_offset=0., decision_belief=None, construction=None):
        if not route_adaptation and decision_belief is None:
            raise ValueError("Frozen-route execution requires the snapshot belief")
        active = cache if construction is None else construction
        return jax.lax.scan(lambda s, i: learning_step(s, i, policy, physical_world,
            noise, active, library, env, cfg, settings, forecast_learning=True,
            route_adaptation=route_adaptation, decision_belief=decision_belief,
            time_offset=time_offset, observations_enabled=observations_enabled,
            tabulated=True), state, jnp.arange(steps))
    return run


class RealExecution:
    """Persistent host scheduler for the original full real POAM estimator."""
    def __init__(self,start,world,cache,library,env,cfg,settings,noise,estimator,seed):
        self.state,self.world,self.cache=start,world,cache
        self.library,self.env,self.cfg,self.settings=library,env,cfg,settings
        self.noise,self.estimator,self.seed=noise,estimator,seed
        self.ticks=0;self.runners={};self.positions=[];self.values=[];self.update_log=[]

    def advance(self,count,policy,decision_belief=None,route_adaptation=True):
        import numpy as np
        from ..wind.hypothetical import from_poam,build_construction_cache
        boundary=round(self.cfg.commit/self.cfg.execution_dt)
        chunks=[]
        while count>0:
            take=min(count,boundary-self.ticks%boundary)
            key=(take,route_adaptation)
            if key not in self.runners:
                self.runners[key]=execution_runner(self.world,self.cache,self.library,self.env,
                    self.cfg,self.settings,take,route_adaptation=route_adaptation)
            self.state,trace=self.runners[key](self.state,policy,self.noise,
                self.ticks*self.cfg.execution_dt,decision_belief,construction=self.cache)
            self.state.execution.x.block_until_ready()
            trace=jax.tree.map(np.asarray,trace);chunks.append(trace)
            earned=trace.observation_sequence>=0
            self.positions.extend(trace.x[earned,:2]);self.values.extend(trace.observation[earned])
            self.ticks+=take;count-=take
            if self.ticks%boundary==0 and self.positions:
                index=self.ticks//boundary-1
                losses=self.estimator.update(jnp.asarray(self.positions),jnp.asarray(self.values),
                    jax.random.fold_in(jax.random.PRNGKey(self.seed),500000+index),
                    train_steps=self.cfg.poam_train_steps)
                before=self.state.belief
                after=from_poam(self.estimator.planning_belief())._replace(
                    observation_count=before.observation_count,posterior_version=before.posterior_version,
                    last_sequence=before.last_sequence,numerical_retries=before.numerical_retries)
                self.cache=build_construction_cache(after,self.cache.eps,self.cfg)
                controller,fields=self.cache.condition(after)
                self.state=self.state._replace(belief=after,controller_mean=controller,construction_fields=fields)
                self.update_log.append({'time':self.ticks*self.cfg.execution_dt,'samples':len(self.positions),
                    'adam_step':self.estimator.adam_step,'final_elbo_loss':losses[-1]})
                self.positions.clear();self.values.clear()
        return self.state,jax.tree.map(lambda *parts:np.concatenate(parts),*chunks)


def run_actual_episode(start, policy, world, cache, library, env, cfg, settings, noise,
                       estimator, seed, *, on_chunk=None):
    """Full real POAM every commit; physical and sensing states are continuous."""
    import numpy as np
    steps=round(cfg.commit/cfg.execution_dt)
    if round(cfg.horizon/cfg.execution_dt)%steps:
        raise ValueError('Mission duration must contain complete execution chunks')
    engine=RealExecution(start,world,cache,library,env,cfg,settings,noise,estimator,seed)
    snapshots=[];chunks=[]
    predict=jax.jit(lambda b:b.predict(env.cells))
    def snapshot():
        mean,cov=predict(engine.state.belief)
        snapshots.append((np.asarray(mean),np.sqrt(np.maximum(np.asarray(cov)[:,0,0],0))))
    snapshot()
    for index in range(round(cfg.horizon/cfg.commit)):
        state,trace=engine.advance(steps,policy)
        snapshot();chunks.append(trace)
        if on_chunk:on_chunk(index,state,trace,engine.update_log[-1] if engine.update_log else None)
    return engine.state,jax.tree.map(lambda *parts:np.concatenate(parts),*chunks),snapshots,engine.update_log
