"""Continuous multi-bend road mission with spatially uncertain tire grip.

Eight physical states: road progress, lateral displacement, heading error,
longitudinal/lateral body velocity, yaw rate, steering angle, drive force.
Known vehicle parameters; uncertain environmental road friction only. Nonlinear
combined tire saturation, quasi-static load transfer, steering/drive lag, body
footprint/lane constraints, and causal inertial-force observations are modeled.
This is a dynamic bicycle model, not a full suspension or tire FEM simulator.
"""

from typing import NamedTuple

import jax
import jax.numpy as jnp

MASS = 1400.
INERTIA = 2200.
LF, LR, HEIGHT = 1.2, 1.5, .52
GRAVITY = 9.81
LENGTH = 175.


def curvature(s):
    s = jnp.asarray(s)
    centers = jnp.array([44., 79., 116., 151.])
    widths = jnp.array([6., 8., 7., 6.])
    amplitudes = jnp.array([.082, -.068, .082, -.078])
    return jnp.sum(amplitudes*jnp.exp(-.5*((s[..., None]-centers)/widths)**2), axis=-1)


def map_weights(position):
    """Bilinear weights on an 8 × 3 road-coordinate grid; full covariance kept."""
    f = jnp.clip(position/jnp.array([25., 2.])+jnp.array([0., 1.]),
                 jnp.array([0., 0.]), jnp.array([6.99999, 1.99999]))
    i, j = jnp.floor(f).astype(jnp.int32)
    a, b = f-jnp.array([i, j])
    ids = jnp.array([j*8+i, j*8+i+1, (j+1)*8+i, (j+1)*8+i+1])
    values = jnp.array([(1-a)*(1-b), a*(1-b), (1-a)*b, a*b])
    return jnp.zeros(24).at[ids].set(values)


class GripBelief(NamedTuple):
    mean: jax.Array
    covariance: jax.Array

    def predict(self, position):
        h = map_weights(position)
        return h@self.mean, jnp.maximum(h@self.covariance@h, 1e-8)


def prior():
    sx, ey = jnp.meshgrid(jnp.arange(8)*25., jnp.array([-2., 0., 2.]))
    positions = jnp.stack((sx.ravel(), ey.ravel()), axis=-1)
    diff = (positions[:, None]-positions[None])/jnp.array([60., 3.])
    covariance = .19**2*jnp.exp(-.5*jnp.sum(diff**2, axis=-1))+.10**2
    return GripBelief(jnp.full(24, .55), covariance+1e-6*jnp.eye(24))


class RoadField(NamedTuple):
    mean: jax.Array
    centers: jax.Array
    widths: jax.Array
    amplitudes: jax.Array

    def at(self, position):
        difference = (position-self.centers)/self.widths
        value = self.mean+jnp.sum(self.amplitudes*jnp.exp(-.5*jnp.sum(difference**2, axis=-1)))
        return jnp.clip(value, .18, 1.05)


def physical_field(seed, mean=.55, patch_scale=.09):
    k1, k2, k3 = jax.random.split(jax.random.PRNGKey(seed), 3)
    centers = jax.random.uniform(k1, (10, 2), minval=jnp.array([0., -2.]), maxval=jnp.array([175., 2.]))
    widths = jax.random.uniform(k2, (10, 2), minval=jnp.array([10., 1.]), maxval=jnp.array([35., 3.]))
    return RoadField(jnp.array(mean), centers, widths, patch_scale*jax.random.normal(k3, (10,)))


def tire_forces(x, grip, normal_scale=1.):
    _, _, _, vx, vy, yaw, steering, drive = x
    v = jnp.maximum(vx, .8)
    # Longitudinal command produces quasi-static load transfer. Mass/inertia,
    # stiffness and actuator parameters are shared by all worlds and methods.
    front_load = jnp.clip(MASS*GRAVITY*normal_scale*LR/(LF+LR)-drive*HEIGHT/(LF+LR), 2000., 11000.)
    loads = jnp.array([front_load, MASS*GRAVITY*normal_scale-front_load])
    slip = jnp.array([steering-jnp.arctan2(vy+LF*yaw, v), -jnp.arctan2(vy-LR*yaw, v)])
    longitudinal = jnp.where(drive<0, drive*jnp.array([.6, .4]), jnp.array([0., drive]))
    raw = jnp.stack((longitudinal, jnp.array([70000., 75000.])*slip), axis=-1)
    magnitude = jnp.sqrt(jnp.sum(raw**2, axis=-1)+1e-8)
    limit = jnp.maximum(grip, .08)*loads
    force = raw*(limit*jnp.tanh(magnitude/limit)/magnitude)[:, None]
    fx = force[0, 0]*jnp.cos(steering)-force[0, 1]*jnp.sin(steering)+force[1, 0]
    fy_front = force[0, 1]*jnp.cos(steering)+force[0, 0]*jnp.sin(steering)
    fy = fy_front+force[1, 1]
    yaw_acceleration = (LF*fy_front-LR*force[1, 1])/INERTIA
    return jnp.array([fx/MASS, fy/MASS, yaw_acceleration])


def derivative(x, command, grip):
    s, e, heading, vx, vy, yaw, steering, drive = x
    k = curvature(s)
    progress = (vx*jnp.cos(heading)-vy*jnp.sin(heading))/jnp.maximum(.5, 1-k*e)
    acceleration = tire_forces(x, grip)
    return jnp.array([
        progress, vx*jnp.sin(heading)+vy*jnp.cos(heading), yaw-k*progress,
        acceleration[0]+vy*yaw-.00045*vx*jnp.abs(vx),
        acceleration[1]-vx*yaw, acceleration[2],
        jnp.clip((command[0]-steering)/.15, -.65, .65),
        jnp.clip((command[1]-drive)/.18, -MASS*9., MASS*9.),
    ])


def step(x, command, field, dt):
    def f(xx):
        grip = jnp.array([field(jnp.array([xx[0]+LF, xx[1]])),
                          field(jnp.array([xx[0]-LR, xx[1]]))])
        return derivative(xx, command, grip)
    k1 = f(x)
    k2 = f(x+dt*k1/2)
    k3 = f(x+dt*k2/2)
    k4 = f(x+dt*k3)
    return x+dt*(k1+2*k2+2*k3+k4)/6


def assimilate(belief, x, observed):
    """EKF update from noisy IMU force/yaw acceleration, never a grip oracle.

    In the low-force tire regime saturation sensitivity tends to zero, so gentle
    driving does not give an artificial direct friction measurement.
    """
    Hpos = jnp.stack((map_weights(jnp.array([x[0]+LF, x[1]])),
                      map_weights(jnp.array([x[0]-LR, x[1]]))))
    local = jnp.clip(Hpos@belief.mean, .08, 1.2)
    predicted = tire_forces(x, local)
    H = jax.jacfwd(lambda mu: tire_forces(x, mu))(local)@Hpos
    R = jnp.diag(jnp.array([.08, .08, .025])**2)
    K = jnp.linalg.solve(H@belief.covariance@H.T+R, H@belief.covariance).T
    mean = belief.mean+K@(observed-predicted)
    A = jnp.eye(24)-K@H
    covariance = A@belief.covariance@A.T+K@R@K.T
    return GripBelief(jnp.clip(mean, .12, 1.1), (covariance+covariance.T)/2)


def policy(theta, x, belief, time, horizon, informed=True):
    grid = jnp.linspace(0, horizon, 4)
    wanted_speed = jnp.interp(time, grid, 6.+2*jnp.tanh(theta[:4]))
    lookahead = jnp.interp(time, grid, 7.+6*jnp.tanh(theta[4:8]))
    target_curvature = curvature(x[0]+lookahead)
    steering = jnp.arctan((LF+LR)*target_curvature)-.12*x[1]-.8*x[2]-.08*(x[5]-x[3]*target_curvature)
    steering_limit = jnp.array(.55)
    if informed:
        mu, variance = belief.predict(jnp.array([x[0]+10., x[1]]))
        conservative_grip = jnp.clip(mu-1.6*jnp.sqrt(variance), .18, 1.05)
        next_curve = jnp.max(jnp.abs(jax.vmap(curvature)(x[0]+jnp.linspace(0, 12., 5))))
        speed_limit = jnp.sqrt(.68*conservative_grip*GRAVITY/jnp.maximum(next_curve, .002))
        wanted_speed = jnp.minimum(wanted_speed, speed_limit)
        # Grip-informed execution limit: a nominal turn may be impossible at
        # the present speed. The planner must predict this input modification.
        # It is an approximate handling envelope, not a proven safety filter.
        steering_limit = jnp.arctan((LF+LR)*.8*conservative_grip*GRAVITY/(x[3]**2+1.))
    drive = MASS*(1.1*(wanted_speed-x[3])+.00045*x[3]**2)
    # Paid, optional identification maneuvers before the demanding road section.
    pulse_grid = jnp.array([0., .6, 1.2, 1.8, horizon])
    drive -= MASS*4.*jnp.interp(time, pulse_grid, jnp.r_[jnp.tanh(theta[8:11])**2, 0., 0.])
    steering += .12*jnp.interp(time, pulse_grid, jnp.r_[jnp.tanh(theta[11:14]), 0., 0.])
    drive = jnp.minimum(drive, MASS*(1.1*(8.05-x[3])+.00045*x[3]**2))
    return jnp.array([jnp.clip(steering, -steering_limit, steering_limit), jnp.clip(drive, -MASS*6., MASS*3.)])


def rollout(theta, x0, belief0, field_values, noise, horizon=8., control_dt=.1,
            substeps=5, anticipate=True, blind=False, truth=None, seconds=None):
    steps = round((horizon if seconds is None else seconds)/control_dt)
    field = ((lambda p: truth.at(p)) if truth is not None else
             ((lambda p: jnp.array(.95)) if blind else
              (lambda p: jnp.clip(map_weights(p)@field_values, .12, 1.1))))

    def tick(carry, item):
        x, belief, incurred, alive = carry
        index, eps = item
        command = policy(theta, x, belief, index*control_dt, horizon, informed=not blind)
        xn = jax.lax.fori_loop(0, substeps, lambda _, state: step(state, command, field, control_dt/substeps), x)
        physical_grip = jnp.array([field(jnp.array([xn[0]+LF, xn[1]])), field(jnp.array([xn[0]-LR, xn[1]]))])
        observed = tire_forces(xn, physical_grip)+jnp.array([.08, .08, .025])*eps
        if anticipate:
            stride = round(.2/control_dt)
            belief = jax.lax.cond(index%stride==stride-1, lambda b: assimilate(b, xn, observed), lambda b: b, belief)
        # Full rectangular footprint approximation, not centerline-only collision.
        lateral_extent = .9*jnp.abs(jnp.cos(xn[2]))+2.2*jnp.abs(jnp.sin(xn[2]))
        lane_gap = 2.0-jnp.abs(xn[1])-lateral_extent
        failed = (lane_gap<0)|(jnp.abs(xn[2])>.8)|(xn[3]<.5)|(~jnp.isfinite(xn).all())
        alive = alive&(~failed)
        cost = control_dt*(jnp.maximum(LENGTH-xn[0], 0)/LENGTH+.025*xn[1]**2+.03*xn[2]**2)
        cost += control_dt*25*jnp.maximum(-lane_gap, 0)**2+control_dt*20*(~alive)
        done = xn[0]>=LENGTH
        cost = jnp.where(x[0]>=LENGTH, 0., cost)
        xn = jnp.where(done&alive, xn.at[0].set(LENGTH), xn)
        return (xn, belief, incurred+cost, alive), (xn, belief.mean, jnp.sqrt(jnp.diag(belief.covariance)), command, lane_gap, cost)

    (last, belief, cost, alive), trace = jax.lax.scan(tick, (x0, belief0, jnp.array(0.), jnp.array(True)), (jnp.arange(steps), noise))
    score = cost+3*jnp.maximum(LENGTH-last[0], 0)/LENGTH
    return score, (last, belief, cost, alive, trace)
