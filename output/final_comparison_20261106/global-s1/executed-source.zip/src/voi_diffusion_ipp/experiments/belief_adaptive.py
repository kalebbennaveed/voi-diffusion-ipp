"""Specified feedback policy on the original two-circle monitoring experiment.

Geometry and clarity data are loaded from the original task file. The explicitly
requested plant is the disturbed double integrator, without the optional drag
extension. Wind is an analytic acceleration field, never a route-cost label.
"""
import json
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import NamedTuple

import jax
import jax.numpy as jnp
import yaml

from ..config import Config, load_config
from ..quarter.continuous import ControlSettings
from .two_region import make_two_region, PassageWind
from .urban_quad import smooth_window

ROOT = Path(__file__).resolve().parents[3]


@dataclass(frozen=True)
class MonitoringSettings(ControlSettings):
    linear_drag: float = 0.
    clarity_decay: float = .16
    target_clarity: float = .70
    initial_clarity: float = .74
    grid_nx: int = 41
    grid_ny: int = 33
    robot_radius: float = 0.  # original planar point robot; CBF margin is separate
    field_evaluation: str = 'direct'
    poam_train_steps: int = 10
    prediction_seconds: float = 45.
    environment_config: str = 'configs/two_region_design.yaml'
    route_timing: str = 'original_segment_bounds'

    def __post_init__(self):
        # Quarter's aircraft-size restrictions do not apply to the original
        # planar point-robot model. Validate this task's physical contract here.
        if self.linear_drag != 0 or self.field_evaluation != 'direct':
            raise ValueError('The requested double integrator and direct field evaluation are mandatory')
        if self.umax <= 0 or self.execution_dt <= 0 or self.sensor_R <= 0:
            raise ValueError('Positive control limit, timestep and sensing noise required')
        if self.clarity_decay <= 0 or not 0 < self.target_clarity < 1:
            raise ValueError('Invalid clarity parameters')
        if abs(self.observation_period/self.execution_dt-round(self.observation_period/self.execution_dt))>1e-6:
            raise ValueError('Observations must align with execution intervals')


@dataclass(frozen=True)
class PolicySettings:
    deformation_scale: float = .025
    latent_bound: float = 3.
    dwell_min: float = 2.
    dwell_max: float = 6.
    arrival_radius: float = .10
    arrival_speed: float = .15
    progress_hysteresis: float = .01
    no_progress_timeout: float = 12.
    traversal_timeout_factor: float = 2.
    traversal_timeout_extra: float = 10.
    feature_points: int = 12
    length_scale: float = 4.
    wind_scale: float = 1.8
    geometry_margin: float = .08


def configuration(path):
    path=Path(path); data=json.loads(path.read_text())
    if data['scenario'] not in ('scenario1','scenario2') or data.get('plant')!='disturbed_double_integrator':
        raise ValueError('Only the two explicitly configured double-integrator cases are supported')
    base=json.loads((path.parent/data['baseline_config']).read_text())['config']
    return data, MonitoringSettings(**(base|data['overrides'])), PolicySettings(**data.get('policy',{}))


def original_task():
    return yaml.safe_load((ROOT/'configs/two_region_design.yaml').read_text())


def task_spec(cfg):
    """Explicit physical design file; original archived setup is unchanged."""
    return yaml.safe_load((ROOT/cfg.environment_config).read_text())


def original_config(cfg):
    from dataclasses import replace
    return replace(load_config(ROOT/'configs/two_region_budgeted.yaml'), linear_drag=0.,
        observation_std=cfg.observation_std, wind_std=cfg.prior_std,
        sensor_sigma=cfg.sensor_sigma, sensor_R=cfg.sensor_R, clarity_decay=cfg.clarity_decay)


class MonitoringEnvironment(NamedTuple):
    original: object
    regions: jax.Array

    @property
    def cells(self): return self.original.cells
    @property
    def targets(self): return self.original.targets
    @property
    def process_noise(self): return self.original.process_noise
    @property
    def obstacles(self): return self.original.obstacles
    @property
    def bounds(self): return self.original.bounds
    def clearance(self,x): return self.original.clearance(x)
    def violations(self,x,margin=0.): return self.original.violations(x,margin)


@lru_cache(maxsize=8)
def make_environment(cfg):
    spec=task_spec(cfg)
    env,_,_,_,_=make_two_region(spec,original_config(cfg))
    centers=jnp.array([spec['region_a'],spec['region_b']]); half=jnp.array(spec['region_size'])/2
    return MonitoringEnvironment(env,jnp.c_[centers-half,centers+half])


def make_real_estimator(cfg):
    # Full original POAM, attentive kernel, sufficient-statistic transport,
    # inducing relocation and variational EM. No fixed-grid replacement.
    spec=task_spec(cfg)
    model=make_two_region(spec,original_config(cfg))[1]
    # Original cold-start procedure: eight noisy sensor readings at the start,
    # not a surveyed route or truth-valued prior. The extra bypass field is
    # exactly zero here, so these data are consistent with both scenarios.
    positions=jnp.tile(jnp.array(spec['region_a']),(8,1))
    noise=cfg.observation_std*jax.random.normal(jax.random.PRNGKey(cfg.seed),(8,2))
    observations=physical_world('scenario1',cfg.wind_strength,cfg=cfg).at(positions)+noise
    model.update(positions,observations,jax.random.PRNGKey(cfg.seed),train_steps=cfg.poam_train_steps)
    return model


def make_prior(cfg):
    return make_real_estimator(cfg).planning_belief()


class PhysicalWorld(NamedTuple):
    central: PassageWind
    bypass_amplitude: jax.Array

    def at(self,locations):
        p=jnp.atleast_2d(locations)
        # Scenario 1 is BIT-FOR-BIT the original analytic passage field.
        # Scenario 2 adds a smooth compact jet in the lower outer corridor.
        # Its support is geometry-fixed; no route identity or policy is queried.
        s=p@self.central.tangent; n=p@self.central.normal
        envelope=smooth_window(s,-1.3,1.3,.35)*smooth_window(n,.85,1.95,.25)
        bypass=self.bypass_amplitude*envelope[:,None]*self.central.tangent
        return self.central.at(p)+bypass


def physical_world(scenario,strength=1.8,*,cfg=None):
    if scenario not in ('scenario1','scenario2','still_air'): raise ValueError(scenario)
    spec=original_task() if cfg is None else task_spec(cfg)
    a,b=jnp.array(spec['region_a']),jnp.array(spec['region_b'])
    t=(b-a)/jnp.linalg.norm(b-a); n=jnp.array([-t[1],t[0]])
    central=PassageWind(t,n,jnp.array(0. if scenario=='still_air' else strength),
                       jnp.array(.2),jnp.array(spec.get('wind_longitudinal_width',1.1)),jnp.array(.35))
    return PhysicalWorld(central,jnp.array(strength if scenario=='scenario2' else 0.))
