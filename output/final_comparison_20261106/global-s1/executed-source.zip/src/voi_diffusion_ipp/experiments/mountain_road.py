"""Nonlinear vehicle mission through a winter mountain-road junction.

Every forecast integrates the eight-state bicycle dynamics, grade forces,
actuator lag, measured acceleration, spatial grip posterior and vehicle footprint.
The two roads are geometric corridors; there are no precomputed route costs.
Policy samples include continuous path offsets, speed, lookahead, optional paid
braking and a posterior-dependent junction decision. Vehicle properties are known.
"""

from typing import NamedTuple

import jax
import jax.numpy as jnp

from .winter_road import GRAVITY, LF, LR, MASS, tire_forces


def smooth(z):
    t = jnp.clip(z, 0.0, 1.0)
    return t * t * (3 - 2 * t)


def center(x, branch):
    upper = 12.0 * smooth((x - 12.0) / 20.0) * (1 - smooth((x - 75.0) / 25.0))
    lower = -48.0 * smooth((x - 12.0) / 30.0) * (1 - smooth((x - 65.0) / 35.0))
    return jnp.where(branch == 0, upper, lower)


def center_derivative(x, branch):
    return jax.grad(lambda xx: center(xx, branch))(x)


def winter_mask(p):
    return jax.nn.sigmoid((p[1] + 0.2) / 0.08)


def map_weights(p):
    f = jnp.clip(
        (p - jnp.array([0.0, -2.0])) / jnp.array([100 / 7, 12.0]),
        jnp.array([0.0, 0.0]),
        jnp.array([6.99999, 1.99999]),
    )
    i, j = jnp.floor(f).astype(jnp.int32)
    a, b = f - jnp.array([i, j])
    ids = jnp.array([j * 8 + i, j * 8 + i + 1, (j + 1) * 8 + i, (j + 1) * 8 + i + 1])
    return (
        jnp.zeros(24).at[ids].set(jnp.array([(1 - a) * (1 - b), a * (1 - b), (1 - a) * b, a * b]))
    )


class GripBelief(NamedTuple):
    mean: jax.Array
    covariance: jax.Array

    def predict(self, p):
        h = map_weights(p)
        mask = winter_mask(p)
        return 0.85 * (1 - mask) + mask * (h @ self.mean), jnp.maximum(
            mask**2 * (h @ self.covariance @ h), 1e-9
        )

    def value(self, p, values):
        mask = winter_mask(p)
        return jnp.clip(0.85 * (1 - mask) + mask * (map_weights(p) @ values), 0.08, 1.1)


def prior():
    xx, yy = jnp.meshgrid(jnp.linspace(0, 100, 8), jnp.array([-2.0, 10.0, 22.0]))
    p = jnp.stack((xx.ravel(), yy.ravel()), axis=-1)
    distance = jnp.sum(((p[:, None] - p[None]) / jnp.array([25.0, 10.0])) ** 2, axis=-1)
    return GripBelief(
        jnp.full(24, 0.52), 0.06**2 * jnp.exp(-0.5 * distance) + 0.28**2 + 1e-6 * jnp.eye(24)
    )


class RoadField(NamedTuple):
    mean: jax.Array
    centers: jax.Array
    widths: jax.Array
    amplitudes: jax.Array

    def at(self, p):
        diff = (p - self.centers) / self.widths
        weather = self.mean + jnp.sum(self.amplitudes * jnp.exp(-0.5 * jnp.sum(diff**2, axis=-1)))
        mask = winter_mask(p)
        return jnp.clip(0.85 * (1 - mask) + mask * weather, 0.08, 1.05)


def physical_field(seed, mean):
    a, b, c = jax.random.split(jax.random.PRNGKey(seed), 3)
    return RoadField(
        jnp.array(mean),
        jax.random.uniform(
            a, (12, 2), minval=jnp.array([0.0, -2.0]), maxval=jnp.array([100.0, 22.0])
        ),
        jax.random.uniform(
            b, (12, 2), minval=jnp.array([8.0, 5.0]), maxval=jnp.array([30.0, 15.0])
        ),
        0.018 * jax.random.normal(c, (12,)),
    )


def terrain(p):
    g = jax.nn.sigmoid((p[1] - 4.0) / 2.0)
    h = 8.0 * jnp.exp(-0.5 * ((p[0] - 55.0) / 18.0) ** 2) * g
    gradient = jnp.array([-h * (p[0] - 55.0) / 18**2, h * (1 - g) / 2.0])
    normal = 1 / jnp.sqrt(1 + gradient @ gradient)
    return h, gradient, normal


def acceleration(x, mu):
    _, slope, normal = terrain(x[:2])
    yaw = x[2]
    grade = (
        -GRAVITY
        * normal
        * jnp.array(
            [
                slope[0] * jnp.cos(yaw) + slope[1] * jnp.sin(yaw),
                -slope[0] * jnp.sin(yaw) + slope[1] * jnp.cos(yaw),
            ]
        )
    )
    return tire_forces(x, mu, normal) + jnp.r_[grade, 0.0]


def derivative(x, command, field):
    _X, _Y, psi, vx, vy, yaw, steering, drive = x
    forward = jnp.array([jnp.cos(psi), jnp.sin(psi)])
    mu = jnp.array([field(x[:2] + LF * forward), field(x[:2] - LR * forward)])
    a = acceleration(x, mu)
    return jnp.array(
        [
            vx * jnp.cos(psi) - vy * jnp.sin(psi),
            vx * jnp.sin(psi) + vy * jnp.cos(psi),
            yaw,
            a[0] + vy * yaw - 0.00045 * vx * jnp.abs(vx),
            a[1] - vx * yaw,
            a[2],
            jnp.clip((command[0] - steering) / 0.15, -0.65, 0.65),
            jnp.clip((command[1] - drive) / 0.18, -MASS * 9.0, MASS * 9.0),
        ]
    )


def step(x, command, field, dt):
    k1 = derivative(x, command, field)
    k2 = derivative(x + dt * k1 / 2, command, field)
    k3 = derivative(x + dt * k2 / 2, command, field)
    k4 = derivative(x + dt * k3, command, field)
    return x + dt * (k1 + 2 * k2 + 2 * k3 + k4) / 6


def assimilate(b, x, observed):
    forward = jnp.array([jnp.cos(x[2]), jnp.sin(x[2])])
    p = jnp.stack((x[:2] + LF * forward, x[:2] - LR * forward))
    Hpos = jax.vmap(lambda r: winter_mask(r) * map_weights(r))(p)
    local = jnp.array([b.predict(p[0])[0], b.predict(p[1])[0]])
    predicted = acceleration(x, local)
    H = jax.jacfwd(lambda mu: acceleration(x, mu))(local) @ Hpos
    R = jnp.diag(jnp.array([0.08, 0.08, 0.025]) ** 2)
    K = jnp.linalg.solve(H @ b.covariance @ H.T + R, H @ b.covariance).T
    A = jnp.eye(24) - K @ H
    covariance = A @ b.covariance @ A.T + K @ R @ K.T
    return GripBelief(
        jnp.clip(b.mean + K @ (observed - predicted), 0.08, 1.1), (covariance + covariance.T) / 2
    )


def chosen_branch(theta, x, b, initial_belief=None):
    # A nominal route plus a response to information acquired AFTER this
    # planning call. Under a frozen belief that response is identically zero.
    reference = b if initial_belief is None else initial_belief
    mean, var = b.predict(jnp.array([8.0, 0.0]))
    m0, v0 = reference.predict(jnp.array([8.0, 0.0]))
    gain = jnp.tanh(theta[13])
    score = theta[12] + gain * (4.0 * (mean - m0) + jnp.sqrt(v0) - jnp.sqrt(var))
    desired = jnp.where(score > 0, 0, 1)
    closest = jnp.argmin(jnp.array([abs(x[1] - center(x[0], 0)), abs(x[1] - center(x[0], 1))]))
    # Follow the road the vehicle has entered at the one-way fork. This
    # prevents a noisy posterior from commanding a late cross-road reversal.
    entered = jnp.where(x[2] > 0.0, 0, 1)
    return jnp.where(x[0] > 22.0, closest, jnp.where(x[0] > 12.0, entered, desired))


def policy(theta, x, b, time, horizon, informed=True, initial_belief=None):
    branch = chosen_branch(theta, x, b, initial_belief)
    look = 3.0 + 5 * jax.nn.sigmoid(theta[11])
    query = x[0] + look
    offsets = 1.2 * jnp.tanh(theta[:8].reshape(2, 4)[branch])
    offset = jnp.interp(query, jnp.array([12.0, 35.0, 70.0, 100.0]), offsets)
    target = jnp.array([query, center(query, branch) + offset])
    delta = target - x[:2]
    alpha = jnp.arctan2(delta[1], delta[0]) - x[2]
    steering = (
        jnp.arctan2(2 * (LF + LR) * jnp.sin(alpha), jnp.maximum(jnp.linalg.norm(delta), 1.0))
        - 0.06 * x[5]
    )
    speed = 4.0 + 2 * jax.nn.sigmoid(theta[8])
    steering_limit = jnp.array(0.6)
    if informed:
        mean, var = b.predict(target)
        mu = jnp.clip(mean - 1.5 * jnp.sqrt(var), 0.1, 1.05)
        slope = center_derivative(query, branch)
        k = jax.grad(lambda xx: center_derivative(xx, branch))(query) / (1 + slope**2) ** 1.5
        speed = jnp.minimum(speed, jnp.sqrt(0.65 * mu * GRAVITY / jnp.maximum(abs(k), 0.002)))
        steering_limit = jnp.arctan((LF + LR) * 0.85 * mu * GRAVITY / (x[3] ** 2 + 1.0))
    _, slope, normal = terrain(x[:2])
    uphill = GRAVITY * normal * (slope[0] * jnp.cos(x[2]) + slope[1] * jnp.sin(x[2]))
    drive = MASS * (1.4 * (speed - x[3]) + 0.00045 * x[3] ** 2 + uphill)
    # Optional braking probe on the shared approach. All its elapsed time and
    # dynamics remain in mission cost. There is no direct parameter observation.
    pulse = jnp.where(time < 1.2, jnp.sin(jnp.pi * time / 1.2) ** 2, 0.0)
    probe = jnp.tanh(theta[9]) ** 2 * pulse
    drive = (1 - probe) * drive - MASS * 5.5 * probe
    steering += (
        0.09
        * jnp.tanh(theta[10])
        * jnp.where(time < 1.2, jnp.sin(2 * jnp.pi * time / 1.2) * pulse, 0.0)
    )
    speed_ceiling = MASS * (1.4 * (6.1 - x[3]) + 0.00045 * x[3] ** 2 + uphill)
    drive = jnp.minimum(drive, speed_ceiling)
    return jnp.array(
        [
            jnp.clip(steering, -steering_limit, steering_limit),
            jnp.clip(drive, -MASS * 6.0, MASS * 4.0),
        ]
    )


def lane_clearance(x):
    def distance(branch):
        slope = center_derivative(x[0], branch)
        lateral = (x[1] - center(x[0], branch)) / jnp.sqrt(1 + slope**2)
        angle = x[2] - jnp.arctan(slope)
        extent = 0.9 * abs(jnp.cos(angle)) + 2.2 * abs(jnp.sin(angle))
        return 3.0 - abs(lateral) - extent

    return jnp.maximum(distance(0), distance(1))


def rollout(
    theta,
    x0,
    b0,
    field_values,
    noise,
    horizon=30.0,
    control_dt=0.1,
    substeps=5,
    anticipate=True,
    blind=False,
    truth=None,
    seconds=None,
    planning_margin=0.0,
):
    n = round((horizon if seconds is None else seconds) / control_dt)
    field = (
        (lambda p: truth.at(p))
        if truth is not None
        else ((lambda p: jnp.array(0.9)) if blind else (lambda p: b0.value(p, field_values)))
    )

    def tick(carry, item):
        x, b, cost, alive, finished = carry
        i, eps = item
        active = alive & (~finished)
        # Blind forecast uses a nominal dry-road belief and omits handling limits.
        controller_b = GripBelief(jnp.full(24, 0.9), jnp.zeros((24, 24))) if blind else b
        command = policy(
            theta,
            x,
            controller_b,
            i * control_dt,
            horizon,
            informed=not blind,
            initial_belief=controller_b if blind else b0,
        )
        xn = jax.lax.fori_loop(
            0, substeps, lambda _, state: step(state, command, field, control_dt / substeps), x
        )
        xn = jnp.where(alive & (~finished), xn, x)
        done = (xn[0] >= 99.0) & (jnp.abs(xn[1]) < 3.0)
        gap = lane_clearance(xn)
        failed = (gap < planning_margin) | (xn[3] < 0.3) | (~jnp.isfinite(xn).all())
        alive = alive & (~failed)
        finished = finished | done
        forward = jnp.array([jnp.cos(xn[2]), jnp.sin(xn[2])])
        mu = jnp.array([field(xn[:2] + LF * forward), field(xn[:2] - LR * forward)])
        observed = acceleration(xn, mu) + jnp.array([0.08, 0.08, 0.025]) * eps
        if anticipate:
            stride = round(0.2 / control_dt)
            b = jax.lax.cond(
                (i % stride == stride - 1) & alive & (~finished),
                lambda old: assimilate(old, xn, observed),
                lambda old: old,
                b,
            )
        increment = jnp.where(
            active, control_dt * (1.0 + 0.001 * (command[1] / MASS) ** 2 + 0.01 * xn[5] ** 2), 0.0
        )
        return (xn, b, cost + increment, alive, finished), (
            xn,
            b.mean,
            jnp.sqrt(jnp.maximum(jnp.diag(b.covariance), 0)),
            command,
            gap,
            increment,
        )

    (last, b, cost, alive, finished), trace = jax.lax.scan(
        tick, (x0, b0, jnp.array(0.0), jnp.array(True), jnp.array(False)), (jnp.arange(n), noise)
    )
    remaining = jnp.linalg.norm(last[:2] - jnp.array([100.0, 0.0])) / 5.0
    return cost + jnp.where(finished, 0.0, remaining) + 100.0 * (~alive), (
        last,
        b,
        cost,
        alive,
        finished,
        trace,
    )
