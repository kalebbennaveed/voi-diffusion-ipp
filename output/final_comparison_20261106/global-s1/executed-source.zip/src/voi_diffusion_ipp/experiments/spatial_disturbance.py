"""Reduced-order non-wind applications of the existing MBD/control composition.

Current: known linear hydrodynamic drag, uncertain spatial water velocity.
Terrain: known mobile platform, uncertain height gradient; small-slope dynamics.
Both use a two-coefficient spatial Gaussian field for a mechanism experiment.
This exact finite-rank belief is deliberately NOT called POAM or full GP mapping.
Existing MBD, sampled policy-value filter, RK4, and actuator limits are reused.
"""

from dataclasses import replace
from typing import NamedTuple

import jax
import jax.numpy as jnp

from ..config import Config
from ..dynamics import step
from ..environment import Environment
from ..planning.budgeted import reference_matrices
from ..safety.rpcbf import filter_control
from ..wind import InnerFields, WorldField


class PotentialBasis(NamedTuple):
    centers: jax.Array
    lengths: jax.Array
    transform: jax.Array

    def jacobian(self, locations):
        """H(p) maps fixed field coefficients to two acceleration components."""
        diff = jnp.atleast_2d(locations)[:, None] - self.centers
        phi = jnp.exp(-0.5 * jnp.sum((diff / self.lengths) ** 2, axis=-1))
        gradient = -diff / self.lengths**2 * phi[..., None]
        return jnp.einsum("ab,nmb->nam", self.transform, gradient)

    def evaluate(self, locations, coefficients):
        return jnp.einsum("nam,m->na", self.jacobian(locations), coefficients)


class SpatialBelief(NamedTuple):
    basis: PotentialBasis
    mean: jax.Array
    covariance: jax.Array
    noise_std: jax.Array

    def mean_at(self, locations):
        return self.basis.evaluate(locations, self.mean)

    def predict(self, locations):
        H = self.basis.jacobian(locations)
        return self.mean_at(locations), jnp.einsum("nam,mk,nbk->nab", H, self.covariance, H)

    def inner_fields(self, eps):
        # Zero covariance remains exactly zero in the no-uncertainty control.
        eigenvalues, vectors = jnp.linalg.eigh(self.covariance)
        root = vectors * jnp.sqrt(jnp.maximum(eigenvalues, 0))[None]
        return InnerFields(self.basis, self.mean + eps @ root.T)

    def condition(self, position, observation):
        H = self.basis.jacobian(position)[0]
        R = self.noise_std**2 * jnp.eye(2)
        K = jnp.linalg.solve(H @ self.covariance @ H.T + R, H @ self.covariance).T
        mean = self.mean + K @ (observation - H @ self.mean)
        A = jnp.eye(len(self.mean)) - K @ H
        covariance = A @ self.covariance @ A.T + K @ R @ K.T
        return self._replace(mean=mean, covariance=(covariance + covariance.T) / 2)


def setup(name):
    if name not in ("current_docking", "terrain_delivery"):
        raise ValueError(name)
    current = name == "current_docking"
    cfg = replace(Config(), dt=0.2, stage_steps=5, future_steps=35, worlds=8,
                  inner_samples=3, backup_steps=8, backup_dt=0.15,
                  linear_drag=1.0, umax=1.6, diffusion_steps=4, proposals=8,
                  temperature=0.08, mbd_latent_bound=6.0, reject_collisions=True)
    # Curl of a streamfunction for incompressible current; negative gradient of
    # gravitational potential for terrain. Do not fit independent force components.
    transform = (0.8 * jnp.array([[0., 1.], [-1., 0.]]) if current
                 else -9.81 * 0.10 * jnp.eye(2))
    basis = PotentialBasis(jnp.array([[-0.7, -0.65], [1.0, 0.65]]),
                           jnp.array([[1.0, 0.8], [0.9, 0.8]]), transform)
    belief = SpatialBelief(basis, jnp.array([0.6, -0.25]),
                           jnp.array([[1.0, 0.15], [0.15, 0.64]]), jnp.array(0.08))
    env = Environment(jnp.zeros((1, 2)), jnp.zeros(1), jnp.array([[0., 0., 0.45]]),
                      jnp.array([[-3.6, -2.2], [3.6, 2.2]]),
                      jnp.array([-2.6, 0.]), jnp.array([2.6, 0.]), jnp.zeros(2), jnp.zeros(1))
    return cfg, env, belief, jnp.array([-2.6, 0., 0., 0.])


def target(time, current):
    return (jnp.array([2.6, 0.25 * jnp.sin(0.5 * time)]),
            jnp.array([0., 0.125 * jnp.cos(0.5 * time)])) if current else (
                jnp.array([2.6, 0.]), jnp.zeros(2))


def rollout(vector, coefficients, noise, inner_eps, belief, env, cfg, name,
            anticipate=True, measurements=True):
    """One chronological 8-second execution; theta never receives field truth.

theta[0:3]: lateral waypoint coordinates (tanh bounded).
theta[3:5]: gains of the observed posterior-mean change on future lateral waypoints.
No observation reward, route reset, hidden-field branch, or second subtraction.
"""
    n = cfg.stage_steps + cfg.future_steps
    current = name == "current_docking"
    final_goal, _ = target(n * cfg.dt, current)
    M, _ = reference_matrices(n * cfg.dt, n)
    world = WorldField(belief.basis, coefficients)
    x0 = jnp.r_[env.roi_a, jnp.zeros(2)]
    prior_mean = belief.mean

    def tick(carry, item):
        x, b, pending, cost = carry
        i, eps = item
        shift = 0.7 * jnp.tanh(vector[3:5] @ (b.mean - prior_mean))
        ys = 1.6 * jnp.tanh(vector[:3]) + shift * jnp.array([0.7, 1., 0.7])
        knots = jnp.stack((jnp.linspace(x0[0], final_goal[0], 5),
                           jnp.r_[x0[1], ys, final_goal[1]]), axis=-1)
        r, vr, ar = M[:, i] @ knots
        nominal = ar + 1.4 * (r - x[:2]) + 2.0 * (vr - x[2:])
        nominal += cfg.linear_drag * x[2:] - b.mean_at(x[:2])[0]
        nominal = jnp.clip(nominal, -cfg.umax, cfg.umax)
        inner = b.inner_fields(inner_eps)
        control, info = filter_control(x, nominal, b, inner, env, cfg)
        xn = step(x, control, lambda p: world.at(p)[0], cfg.dt, cfg.linear_drag)
        goal, _ = target((i + 1) * cfg.dt, current)
        # Arrival quality and effort are task costs, not an information bonus.
        increment = cfg.dt * (0.025 * jnp.sum((xn[:2] - goal)**2)
                               + (0.02 if current else 0.06) * jnp.sum(control**2))
        observed = world.at(xn[:2])[0] + b.noise_std * eps
        if anticipate and measurements:
            pending = pending.condition(xn[:2], observed)
            # Assimilate acquired data every second; current input cannot see it.
            b = jax.lax.cond((i + 1) % cfg.stage_steps == 0, lambda _: pending, lambda _: b, None)
        times = cfg.dt * jnp.array([0.25, 0.5, 0.75, 1.])
        mids = jax.vmap(lambda dt: step(x, control, lambda p: world.at(p)[0], dt, cfg.linear_drag))(times)
        clearance = jnp.min(jax.vmap(env.clearance)(mids))
        return (xn, b, pending, cost + increment), (
            xn, control, clearance, info.slack, b.mean, jnp.trace(b.covariance), increment)

    (last, _, _, cost), trace = jax.lax.scan(tick, (x0, belief, belief, jnp.array(0.)),
                                           (jnp.arange(n), noise))
    goal, velocity = target(n * cfg.dt, current)
    terminal_error = jnp.linalg.norm(last[:2] - goal)
    terminal_speed_error = jnp.linalg.norm(last[2:] - velocity)
    cost += 8.0 * terminal_error**2 + 2.0 * terminal_speed_error**2
    xs, controls, clearance, slack, means, variance, increments = trace
    return {"cost": cost, "path": jnp.concatenate((x0[None], xs)), "controls": controls,
            "clearance": clearance.min(), "max_slack": slack.max(),
            "terminal_error": terminal_error, "terminal_speed_error": terminal_speed_error,
            "posterior_mean": means, "coefficient_variance": variance,
            "running_cost": increments}


def evaluate(vector, coefficients, noise, inner_eps, belief, env, cfg, name,
             anticipate=True, measurements=True):
    return jax.lax.map(lambda item: rollout(vector, item[0], item[1], inner_eps,
                        belief, env, cfg, name, anticipate, measurements), (coefficients, noise))


def initial_policies():
    return jnp.array([[y, y, y, 0., 0.] for y in (-0.8, 0.8, -0.4, 0.4, 0.)])
