"""Seven-joint MuJoCo contact inspection environment.

The Panda geometry/inertial parameters come from DeepMind Menagerie. All seven
joints are torque controlled with the model's original torque limits. Spatial
sliding friction belongs to the panel and is only available to the physics.
Controller estimates must be supplied separately; no controller receives truth.
This is an environment prototype, not an established learning-benefit result.
"""

import xml.etree.ElementTree as ET
from pathlib import Path

import mujoco
import numpy as np
from scipy.spatial.transform import Rotation

ROOT = Path(__file__).resolve().parents[3]
ROBOT = ROOT / "vendor/mujoco_panda"
PANEL_CENTER = np.array([0.5, 0.0, 0.24])
PANEL_HALF = np.array([0.22, 0.22])
TOOL_RADIUS = 0.025


def model_xml(timestep=0.002):
    root = ET.parse(ROBOT / "panda_nohand.xml").getroot()
    root.set("model", "Panda contact inspection with spatial surface friction")
    root.find("compiler").set("meshdir", str(ROBOT / "assets"))
    option = root.find("option")
    option.set("timestep", str(timestep))
    option.set("cone", "elliptic")
    option.set("iterations", "40")
    visual = ET.SubElement(root, "visual")
    ET.SubElement(visual, "global", offwidth="1280", offheight="960")
    # Original self-collision geoms stay active. The panel collides with arm
    # and probe, while only probe/panel contact contributes useful sensing.
    wb = root.find("worldbody")
    ET.SubElement(wb, "light", pos="0.5 -0.5 1.5", dir="0 0 -1")
    ET.SubElement(
        wb,
        "geom",
        name="floor",
        type="plane",
        size="2 2 .1",
        rgba=".86 .89 .92 1",
        contype="0",
        conaffinity="0",
    )
    ET.SubElement(
        wb,
        "geom",
        name="panel",
        type="box",
        pos=".5 0 .22",
        size=".22 .22 .02",
        rgba=".3 .49 .56 1",
        contype="3",
        conaffinity="3",
        priority="2",
        condim="3",
        friction=".4 .001 .0001",
        solref=".03 1",
    )
    ET.SubElement(
        wb, "camera", name="overview", pos="1.25 -1.4 1.1", xyaxes=".75 .66 0 -.33 .38 .87"
    )
    attachment = wb.find(".//body[@name='attachment']")
    ET.SubElement(
        attachment,
        "geom",
        name="probe",
        type="sphere",
        size=str(TOOL_RADIUS),
        pos="0 0 .035",
        mass=".35",
        rgba=".95 .65 .1 1",
        contype="2",
        conaffinity="2",
        friction=".4 .001 .0001",
        condim="3",
    )
    ET.SubElement(attachment, "site", name="probe_center", pos="0 0 .035", size=".004")
    actuator = root.find("actuator")
    actuator.clear()
    for i, limit in enumerate([87, 87, 87, 87, 12, 12, 12], 1):
        ET.SubElement(
            actuator,
            "motor",
            name=f"torque{i}",
            joint=f"joint{i}",
            ctrlrange=f"{-limit} {limit}",
            forcerange=f"{-limit} {limit}",
        )
    root.find("keyframe").clear()
    return ET.tostring(root, encoding="unicode")


def surface_friction(position, seed=1):
    """A continuous 2D material field with many independent patches.

    Seeds alter the spatial field, not the robot. The controller never calls this.
    This is deliberately independent of the estimator's discretization/basis.
    """
    p = np.asarray(position)[..., :2]
    rng = np.random.default_rng(seed)
    centers = rng.uniform([0.28, -0.22], [0.72, 0.22], (12, 2))
    widths = rng.uniform(0.035, 0.11, (12, 2))
    amplitudes = rng.normal(0, 1.4, 12)
    z = -0.3 + (
        np.exp(-0.5 * np.sum(((p[..., None, :] - centers) / widths) ** 2, axis=-1)) * amplitudes
    ).sum(-1)
    return 0.08 + 0.85 / (1 + np.exp(-z))


class PandaContact:
    def __init__(self, seed=1, timestep=0.002):
        self.model = mujoco.MjModel.from_xml_string(model_xml(timestep))
        self.data = mujoco.MjData(self.model)
        self.seed = seed
        self.physics_friction = lambda p: surface_friction(p, self.seed)
        self.force_command = 0.0
        self.site = self.model.site("probe_center").id
        self.panel = self.model.geom("panel").id
        self.probe = self.model.geom("probe").id
        self.jacp = np.zeros((3, self.model.nv))
        self.jacr = self.jacp.copy()
        self.force = np.zeros(6)
        self.home = np.array([0, -0.4, 0, -2.0, 0, 1.6, -0.7854])
        self.data.qpos[:] = self.home
        mujoco.mj_forward(self.model, self.data)
        self.orientation = self.data.site_xmat[self.site].reshape(3, 3).copy()
        self.set_pose(np.array([0.39, -0.14, 0.24 + TOOL_RADIUS + 0.004]))
        self.home = self.data.qpos.copy()
        self.rotation = Rotation.from_matrix(self.data.site_xmat[self.site].reshape(3, 3))

    @property
    def position(self):
        return self.data.site_xpos[self.site].copy()

    def set_pose(self, target):
        """Initial geometric IK; this does not move/reset the mission afterward."""
        for _ in range(300):
            mujoco.mj_forward(self.model, self.data)
            error = target - self.position
            mujoco.mj_jacSite(self.model, self.data, self.jacp, self.jacr, self.site)
            R = self.data.site_xmat[self.site].reshape(3, 3)
            orientation_error = Rotation.from_matrix(self.orientation @ R.T).as_rotvec()
            J = np.vstack((self.jacp, self.jacr))
            increment = J.T @ np.linalg.solve(
                J @ J.T + 0.0001 * np.eye(6), np.r_[error, orientation_error]
            )
            self.data.qpos[:] = np.clip(
                self.data.qpos + 0.4 * increment,
                self.model.jnt_range[:, 0] + 0.01,
                self.model.jnt_range[:, 1] - 0.01,
            )
            if np.linalg.norm(error) < 1e-6:
                break
        mujoco.mj_forward(self.model, self.data)
        self.data.qvel[:] = 0

    def observe_contact(self):
        normal = 0.0
        tangential = np.zeros(3)
        for i in range(self.data.ncon):
            c = self.data.contact[i]
            if {c.geom1, c.geom2} == {self.panel, self.probe}:
                mujoco.mj_contactForce(self.model, self.data, i, self.force)
                normal += abs(self.force[0])
                tangential += self.force[1:3] @ c.frame.reshape(3, 3)[1:]
        return normal, np.linalg.norm(tangential)

    def tick(self, reference, velocity, friction_estimate, normal_force=12.0):
        """Task-space impedance plus estimated sliding-force compensation.

        The controller uses its estimate, while contact physics uses the hidden
        surface field. Saturation is applied at the seven joint torques.
        """
        d, m = self.data, self.model
        self.force_command += np.clip(
            normal_force - self.force_command, -20 * m.opt.timestep, 20 * m.opt.timestep
        )
        normal_force = self.force_command
        mujoco.mj_jacSite(m, d, self.jacp, self.jacr, self.site)
        p = self.position
        v = self.jacp @ d.qvel
        target = np.r_[reference, PANEL_CENTER[2] + TOOL_RADIUS]
        linear_force = (
            np.array([450.0, 450.0, 800.0]) * (target - p) - np.array([40.0, 40.0, 50.0]) * v
        )
        linear_force[:2] += 40 * np.asarray(velocity)
        linear_force[2] -= normal_force
        # Measured-load feedback is available to every execution controller.
        # A soft-contact model needs pressure feedback, not an ideal held load.
        measured_normal, _ = self.observe_contact()
        linear_force[2] += 0.4 * np.clip(
            measured_normal - normal_force, -normal_force, 2 * normal_force
        )
        linear_force[2] = np.clip(linear_force[2], -25.0, 25.0)
        direction = np.r_[velocity, 0.0]
        direction /= max(np.linalg.norm(direction), 0.003)
        linear_force += float(friction_estimate) * normal_force * direction
        current = Rotation.from_matrix(d.site_xmat[self.site].reshape(3, 3))
        rotation_error = (self.rotation * current.inv()).as_rotvec()
        wrench = np.r_[linear_force, 35 * rotation_error - 4 * (self.jacr @ d.qvel)]
        J = np.vstack((self.jacp, self.jacr))
        # Nullspace posture term; gravity/Coriolis compensation uses known robot.
        N = np.eye(7) - J.T @ np.linalg.solve(J @ J.T + 1e-5 * np.eye(6), J)
        torque = d.qfrc_bias + J.T @ wrench + N @ (8 * (self.home - d.qpos) - 2 * d.qvel)
        limits = m.actuator_ctrlrange[:, 1]
        d.ctrl[:] = np.clip(torque, -limits, limits)
        m.geom_friction[self.panel, 0] = self.physics_friction(p)
        mujoco.mj_step(m, d)
        normal, tangential = self.observe_contact()
        return {
            "position": self.position,
            "velocity": v,
            "normal": normal,
            "tangential": tangential,
            "torques": d.ctrl.copy(),
            "saturated": np.any(abs(torque) > limits),
            "joint_position": d.qpos.copy(),
            "joint_velocity": d.qvel.copy(),
        }
