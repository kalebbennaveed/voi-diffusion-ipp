"""Six-DOF ROV inspection with spatial flow, actuator states and camera coverage.

Synthetic control-oriented model, not CFD or a calibrated commercial ROV.
Known rigid-body/added inertia, Coriolis terms, water-relative nonlinear drag,
restoring moments, eight bounded lagged thrusters and electrical work are kept
inside every prediction. The uncertain quantity is an external current map.
See Fossen's marine craft model: https://www.fossen.biz/html/marineCraftModel.html
"""

from typing import NamedTuple

import jax
import jax.numpy as jnp

MASS = 35.0
MR = jnp.array([MASS, MASS, MASS, 0.8, 1.0, 1.2])
MA = jnp.array([8.0, 12.0, 15.0, 0.1, 0.15, 0.2])
DRAG_LINEAR = jnp.array([8.0, 12.0, 14.0, 0.6, 0.8, 0.9])
DRAG_QUADRATIC = jnp.array([23.0, 32.0, 36.0, 0.4, 0.6, 0.7])
THRUSTER_LIMIT = jnp.array([18.0, 18.0, 18.0, 18.0, 13.0, 13.0, 13.0, 13.0])
POSITIONS = jnp.array(
    [
        [0.25, 0.18, 0.0],
        [0.25, -0.18, 0.0],
        [-0.25, 0.18, 0.0],
        [-0.25, -0.18, 0.0],
        [0.25, 0.18, 0.0],
        [0.25, -0.18, 0.0],
        [-0.25, 0.18, 0.0],
        [-0.25, -0.18, 0.0],
    ]
)
DIRECTIONS = jnp.array(
    [
        [1.0, -1.0, 0.0],
        [1.0, 1.0, 0.0],
        [1.0, 1.0, 0.0],
        [1.0, -1.0, 0.0],
        [0.0, 0.0, 1.0],
        [0.0, 0.0, 1.0],
        [0.0, 0.0, 1.0],
        [0.0, 0.0, 1.0],
    ]
)
DIRECTIONS = DIRECTIONS / jnp.linalg.norm(DIRECTIONS, axis=1)[:, None]
ALLOCATION = jnp.concatenate((DIRECTIONS, jnp.cross(POSITIONS, DIRECTIONS)), axis=1).T
ALLOCATE = jnp.linalg.pinv(ALLOCATION)
ALLOCATION_WEIGHT = jnp.array([1.0, 1.0, 1.0, 15.0, 15.0, 10.0])
WEIGHTED_ALLOCATION = ALLOCATION_WEIGHT[:, None] * ALLOCATION
ALLOCATION_HESSIAN = WEIGHTED_ALLOCATION.T @ WEIGHTED_ALLOCATION
ALLOCATION_STEP = 0.95 / jnp.linalg.eigvalsh(ALLOCATION_HESSIAN)[-1]
STRUCTURES = jnp.array([[8.0, 0.0], [15.0, 0.0], [22.0, 0.0]])
RADIUS = 1.9
BODY_RADIUS = 0.36
GROUPS = jnp.array(
    [[x, side * RADIUS, z] for x in [8.0, 15.0, 22.0] for side in [-1.0, 1.0] for z in [2.5, 6.5]]
)
NORMALS = jnp.array(
    [[0.0, side, 0.0] for _ in [8.0, 15.0, 22.0] for side in [-1.0, 1.0] for _ in [2.5, 6.5]]
)
GROUP_COUNT = len(GROUPS)
TARGETS = (
    GROUPS[:, None, :]
    + jnp.array([[-0.35, 0.0, -0.3], [0.35, 0.0, -0.3], [-0.35, 0.0, 0.3], [0.35, 0.0, 0.3]])[
        None, :, :
    ]
).reshape(-1, 3)
xx, yy, zz = jnp.meshgrid(
    jnp.array([-2.0, 4.0, 10.0, 16.0, 22.0, 28.0]),
    jnp.array([-5.0, 0.0, 5.0]),
    jnp.array([2.0, 7.0]),
    indexing="ij",
)
NODES = jnp.stack((xx.ravel(), yy.ravel(), zz.ravel()), axis=1)
N = NODES.shape[0]
GP_DIM = N * 3
FLOW_STD = 0.40
FLOW_PROFILE = "uniform"
SENSOR_POLICY = "continuous"
PROBE_SECONDS = 2.5
BELIEF_RECOURSE = False
GEOMETRY = "array"
START_DEPTH = 4.5
HANDLING_CLEARANCE = 0.12


def configure(
    spacing=7.0,
    current_std=0.40,
    flow_profile="uniform",
    sensor_policy="continuous",
    probe_seconds=2.5,
    belief_recourse=False,
    geometry="array",
    start_depth=4.5,
    handling_clearance=0.12,
):
    """Load a static synthetic scene before compiling a mission process."""
    global \
        STRUCTURES, \
        GROUPS, \
        NORMALS, \
        GROUP_COUNT, \
        TARGETS, \
        FLOW_STD, \
        FLOW_PROFILE, \
        SENSOR_POLICY, \
        PROBE_SECONDS, \
        BELIEF_RECOURSE, \
        GEOMETRY, \
        START_DEPTH, \
        HANDLING_CLEARANCE
    columns = [8.0, 8.0 + spacing, 8.0 + 2 * spacing]
    obstacle_x = jnp.linspace(columns[0], columns[-1], 9) if geometry == "connected" else columns
    STRUCTURES = jnp.array([[x, 0.0] for x in obstacle_x])
    GROUPS = jnp.array(
        [[x, side * RADIUS, z] for x in columns for side in [-1.0, 1.0] for z in [2.5, 6.5]]
    )
    NORMALS = jnp.array(
        [[0.0, side, 0.0] for _ in columns for side in [-1.0, 1.0] for _ in [2.5, 6.5]]
    )
    GROUP_COUNT = len(GROUPS)
    TARGETS = (
        GROUPS[:, None, :]
        + jnp.array([[-0.35, 0.0, -0.3], [0.35, 0.0, -0.3], [-0.35, 0.0, 0.3], [0.35, 0.0, 0.3]])[
            None, :, :
        ]
    ).reshape(-1, 3)
    FLOW_STD = float(current_std)
    FLOW_PROFILE = flow_profile
    SENSOR_POLICY = sensor_policy
    PROBE_SECONDS = float(probe_seconds)
    BELIEF_RECOURSE = bool(belief_recourse)
    GEOMETRY = geometry
    START_DEPTH = float(start_depth)
    HANDLING_CLEARANCE = float(handling_clearance)


def rotation(angles):
    a, b, c = angles
    sa, ca = jnp.sin(a), jnp.cos(a)
    sb, cb = jnp.sin(b), jnp.cos(b)
    sc, cc = jnp.sin(c), jnp.cos(c)
    return jnp.array(
        [
            [cc * cb, cc * sb * sa - sc * ca, cc * sb * ca + sc * sa],
            [sc * cb, sc * sb * sa + cc * ca, sc * sb * ca - cc * sa],
            [-sb, cb * sa, cb * ca],
        ]
    )


def weights(p):
    distance = jnp.sum(((p - NODES) / jnp.array([5.0, 4.0, 4.0])) ** 2, axis=1)
    return jax.nn.softmax(-0.5 * distance)


class CurrentBelief(NamedTuple):
    mean: jax.Array
    covariance: jax.Array

    def predict(self, p):
        h = weights(p)
        blocks = self.covariance.reshape(N, 3, N, 3)
        average = (blocks[:, 0, :, 0] + blocks[:, 1, :, 1] + blocks[:, 2, :, 2]) / 3.0
        return h @ self.mean, jnp.maximum(h @ average @ h, 1e-9)


def point_operator(p):
    return jnp.kron(weights(p)[None, :], jnp.eye(3))


def capsule_distance(point):
    """Distance to the connected structure's centre-line segment in the xy plane."""
    axis = jnp.array([jnp.clip(point[0], STRUCTURES[0, 0], STRUCTURES[-1, 0]), 0.0])
    return jnp.linalg.norm(point[:2] - axis)


def capsule_segment_distance(start, end):
    """Exact planar distance between a query segment and the hull centre line."""
    left, right = STRUCTURES[0, 0], STRUCTURES[-1, 0]
    endpoints = jnp.array([[left, 0.0], [right, 0.0]])
    delta = end - start
    t = jnp.clip((endpoints - start) @ delta / jnp.maximum(delta @ delta, 1e-9), 0.0, 1.0)
    closest = start + t[:, None] * delta
    endpoint_distance = jnp.min(jnp.linalg.norm(endpoints - closest, axis=1))
    on_axis = jnp.array(
        [[jnp.clip(start[0], left, right), 0.0], [jnp.clip(end[0], left, right), 0.0]]
    )
    endpoint_distance = jnp.minimum(
        endpoint_distance, jnp.min(jnp.linalg.norm(jnp.stack((start, end)) - on_axis, axis=1))
    )
    crossing_t = -start[1] / jnp.where(jnp.abs(delta[1]) > 1e-9, delta[1], 1e-9)
    crossing_x = start[0] + crossing_t * delta[0]
    intersects = (
        (crossing_t >= 0.0) & (crossing_t <= 1.0) & (crossing_x >= left) & (crossing_x <= right)
    )
    return jnp.where(intersects, 0.0, endpoint_distance)


def connected_waypoint(position, target, radius):
    """A six-node visibility graph routes around the continuous obstacle.

    The old nearest-cylinder tangent can become trapped between overlapping
    cylinders. This shared geometric guidance accounts for the entire capsule.
    It does not use physical truth or a hypothetical future measurement.
    """
    p, goal = position[:2], target[:2]
    left, right = STRUCTURES[0, 0] - radius - 0.25, STRUCTURES[-1, 0] + radius + 0.25
    corners = jnp.array(
        [
            [left, -radius - 0.25],
            [left, radius + 0.25],
            [right, -radius - 0.25],
            [right, radius + 0.25],
        ]
    )
    nodes = jnp.concatenate((p[None], goal[None], corners), axis=0)
    lengths = jnp.linalg.norm(nodes[:, None] - nodes[None], axis=2)
    clearance_matrix = jax.vmap(
        lambda a: jax.vmap(lambda b: capsule_segment_distance(a, b))(nodes)
    )(nodes)
    edges = jnp.where(
        (clearance_matrix >= radius - 1e-4) & (~jnp.eye(6, dtype=bool)), lengths, jnp.inf
    )
    edges = edges.at[0, 2:].set(jnp.where(lengths[0, 2:] < 0.15, jnp.inf, edges[0, 2:]))
    distance = jnp.full(6, jnp.inf).at[1].set(0.0)
    distance = jax.lax.fori_loop(
        0, 5, lambda _, d: jnp.minimum(d, jnp.min(edges + d[None, :], axis=1)), distance
    )
    waypoint = nodes[jnp.argmin(edges[0] + distance)]
    axis = jnp.array([jnp.clip(p[0], STRUCTURES[0, 0], STRUCTURES[-1, 0]), 0.0])
    normal = p - axis
    length = jnp.linalg.norm(normal)
    projected = axis + normal / jnp.maximum(length, 1e-6) * (radius + 0.2)
    waypoint = jnp.where(length < radius + 0.05, projected, waypoint)
    return target.at[:2].set(waypoint)


def prior():
    separation = (NODES[:, None, :] - NODES[None, :, :]) / jnp.array([7.0, 4.0, 5.0])
    covariance = FLOW_STD**2 * jnp.exp(-0.5 * jnp.sum(separation**2, axis=-1)) + 1e-5 * jnp.eye(N)
    if FLOW_PROFILE == "contrast":
        # Uncertain environmental shear chooses which side is easier to hold.
        # A coherent contrast mode plus a spatial residual, not a changed robot.
        reference = weights(jnp.array([15.0, 3.0, 4.5])) @ NODES[:, 1]
        mode = jnp.zeros((N, 3)).at[:, 0].set(NODES[:, 1] / reference)
        covariance = 0.12**2 * covariance / FLOW_STD**2
        vector_covariance = jnp.kron(covariance, jnp.eye(3)) + FLOW_STD**2 * jnp.outer(
            mode.ravel(), mode.ravel()
        )
        return CurrentBelief(jnp.tile(jnp.array([0.75, 0.0, 0.0]), (N, 1)), vector_covariance)
    background = (
        jnp.full(N, 0.35)
        if FLOW_PROFILE == "uniform"
        else (0.3 + 1.1 * jax.nn.sigmoid(-NODES[:, 1]))
    )
    return CurrentBelief(
        jnp.stack((background, jnp.zeros(N), jnp.zeros(N)), axis=1),
        jnp.kron(covariance, jnp.eye(3)),
    )


def physical_field(seed, scale=1.0):
    b = prior()
    return b.mean + scale * (
        jnp.linalg.cholesky(b.covariance) @ jax.random.normal(jax.random.PRNGKey(seed), (GP_DIM,))
    ).reshape(N, 3)


def assimilate(b, p, measurement):
    return condition(b, point_operator(p), measurement, 0.07)


def condition(b, h, measurement, sigma):
    cross = b.covariance @ h.T
    gain = jnp.linalg.solve(h @ cross + sigma**2 * jnp.eye(h.shape[0]), cross.T).T
    mean = b.mean.ravel() + gain @ (measurement - h @ b.mean.ravel())
    covariance = b.covariance - gain @ cross.T
    return CurrentBelief(mean.reshape(N, 3), (covariance + covariance.T) / 2)


def beam_operator(x):
    """Finite water cells of four 25-degree Janus beams, with geometric occlusion.

    Each surviving beam measures one radial component at its own spatial cell.
    A partial return still updates that component; no artificial all-beam gate
    or direct three-component flow observation is used.
    """
    a = jnp.deg2rad(25.0)
    directions = (
        jnp.array(
            [
                [jnp.sin(a), 0.0, -jnp.cos(a)],
                [-jnp.sin(a), 0.0, -jnp.cos(a)],
                [0.0, jnp.sin(a), -jnp.cos(a)],
                [0.0, -jnp.sin(a), -jnp.cos(a)],
            ]
        )
        @ rotation(x[3:6]).T
    )
    cells = x[None, None, :3] + directions[:, None, :] * jnp.array([3.75, 4.0, 4.25])[None, :, None]
    endpoint = cells[:, -1, :]
    delta = endpoint[:, :2] - x[:2]
    centers = STRUCTURES[None, :, :] - x[None, None, :2]
    t = jnp.einsum(
        "bci,bi->bc", jnp.broadcast_to(centers, (4, len(STRUCTURES), 2)), delta
    ) / jnp.maximum(jnp.sum(delta**2, axis=1)[:, None], 1e-8)
    closest = x[None, None, :2] + jnp.clip(t, 0.0, 1.0)[:, :, None] * delta[:, None, :]
    blocked = jnp.any(jnp.linalg.norm(closest - STRUCTURES[None, :, :], axis=2) < RADIUS, axis=1)
    if GEOMETRY == "connected":
        blocked = (
            jax.vmap(lambda point: capsule_segment_distance(x[:2], point))(endpoint[:, :2]) < RADIUS
        )
    valid = (endpoint[:, 2] > 0.6) & (~blocked)
    hpos = jnp.mean(jax.vmap(jax.vmap(weights))(cells), axis=1)
    h = (hpos[:, :, None] * directions[:, None, :]).reshape(4, GP_DIM) * valid[:, None]
    return h, valid, cells, directions


def observe_and_update(b, x, values, eps):
    if SENSOR_POLICY == "continuous":
        return assimilate(b, x[:3], weights(x[:3]) @ values + 0.07 * eps[:3])
    h, valid, _, _ = beam_operator(x)
    observation = h @ values.ravel() + 0.04 * eps * valid
    return condition(b, h, observation, 0.04)


def coriolis_action(inertia, velocity):
    linear, angular = velocity[:3], velocity[3:]
    momentum = inertia[:3] * linear
    spin = inertia[3:] * angular
    return jnp.r_[
        jnp.cross(angular, momentum), jnp.cross(linear, momentum) + jnp.cross(angular, spin)
    ]


def allocate_thrusters(wrench):
    """Bounded weighted allocation, prioritizing attitude when thrust is scarce.

    Twenty-four projected-gradient iterations approximate the box-constrained
    least-squares allocation. They are reproduced inside every prediction.
    """
    rhs = WEIGHTED_ALLOCATION.T @ (ALLOCATION_WEIGHT * wrench)
    initial = jnp.clip(ALLOCATE @ wrench, -THRUSTER_LIMIT, THRUSTER_LIMIT)
    return jax.lax.fori_loop(
        0,
        24,
        lambda _, u: jnp.clip(
            u - ALLOCATION_STEP * (ALLOCATION_HESSIAN @ u - rhs), -THRUSTER_LIMIT, THRUSTER_LIMIT
        ),
        initial,
    )


def environmental_wrench(x, field):
    """Known inertial/drag terms; only the supplied spatial water field differs."""
    p, angles, nu = x[:3], x[3:6], x[6:12]
    R = rotation(angles)
    ground = R @ nu[:3]
    water = field(p)
    body_water = R.T @ water
    relative = nu - jnp.r_[body_water, jnp.zeros(3)]
    dc = -jnp.cross(nu[3:], body_water) + R.T @ jax.jacfwd(field)(p) @ ground
    drag = (DRAG_LINEAR + DRAG_QUADRATIC * jnp.abs(relative)) * relative
    restoring = jnp.array([0.0, 0.0, 0.0, 2.0 * jnp.sin(angles[0]), 2.5 * jnp.sin(angles[1]), 0.0])
    return (
        coriolis_action(MR, nu)
        + coriolis_action(MA, relative)
        + drag
        + restoring
        - MA * jnp.r_[dc, jnp.zeros(3)]
    )


def derivative(x, command, field):
    angles, nu, thrust = x[3:6], x[6:12], x[12:20]
    R = rotation(angles)
    ground = R @ nu[:3]
    nudot = (ALLOCATION @ thrust - environmental_wrench(x, field)) / (MR + MA)
    a, b, _ = angles
    cb = jnp.maximum(jnp.cos(b), 0.2)
    T = jnp.array(
        [
            [1.0, jnp.sin(a) * jnp.sin(b) / cb, jnp.cos(a) * jnp.sin(b) / cb],
            [0.0, jnp.cos(a), -jnp.sin(a)],
            [0.0, jnp.sin(a) / cb, jnp.cos(a) / cb],
        ]
    )
    # x[20] is cumulative electrical work in joules, including hotel load.
    power = 35.0 + 2.2 * jnp.sum(jnp.abs(thrust) ** 1.5)
    return jnp.r_[
        ground, T @ nu[3:], nudot, jnp.clip((command - thrust) / 0.18, -150.0, 150.0), power
    ]


def step(x, command, values, dt):
    field = lambda p: weights(p) @ values
    f = lambda state: derivative(state, command, field)
    k1 = f(x)
    k2 = f(x + dt * k1 / 2)
    k3 = f(x + dt * k2 / 2)
    k4 = f(x + dt * k3)
    return x + dt * (k1 + 2 * k2 + 2 * k3 + k4) / 6


def clearance(p):
    cylinders = jnp.linalg.norm(p[:2] - STRUCTURES, axis=1) - RADIUS - BODY_RADIUS
    structure_gap = (
        capsule_distance(p) - RADIUS - BODY_RADIUS
        if GEOMETRY == "connected"
        else jnp.min(cylinders)
    )
    walls = (
        jnp.array([p[0] + 4.0, 30.0 - p[0], p[1] + 7.0, 7.0 - p[1], p[2] - 0.6, 9.5 - p[2]])
        - BODY_RADIUS
    )
    return jnp.minimum(structure_gap, jnp.min(walls))


def holding_quality(b):
    """Shared inspection-choice feedback from predicted actuator demand.

    Evaluate stationary reference camera poses one metre from each panel.
    High thrust utilization and unattainable wrench reduce an inspection's
    priority. This is a nominal policy design, not an extra objective reward or
    a claim that dynamic tracking/clearance is guaranteed.
    """
    field = lambda p: weights(p) @ b.mean

    def at_panel(surface, normal):
        pose = jnp.zeros(21).at[:3].set(surface + normal)
        pose = pose.at[5].set(jnp.arctan2(-normal[1], -normal[0]))
        demand = environmental_wrench(pose, field)
        thrust = allocate_thrusters(demand)
        residual = ALLOCATION @ thrust - demand
        load = jnp.max(jnp.abs(thrust) / THRUSTER_LIMIT)
        return 1.0 / (
            1.0 + load**4 + jnp.sum((residual[:3] / 2.0) ** 2) + jnp.sum((residual[3:] / 0.15) ** 2)
        )

    return jax.vmap(at_panel)(GROUPS, NORMALS)


def inspection_group(theta, x, q, holding):
    deficits = jnp.mean(jnp.maximum(0.75 - q.reshape(GROUP_COUNT, 4), 0.0), axis=1)
    distance = jnp.linalg.norm(GROUPS - x[:3], axis=1)
    # Shared spatial monitoring feedback, with continuously optimized priorities.
    return jnp.argmax(deficits * holding + 0.14 * jnp.tanh(theta[:GROUP_COUNT]) - 0.012 * distance)


def control(theta, x, q, b, time, informed=True, holding=None):
    if holding is None:
        holding = holding_quality(b) if BELIEF_RECOURSE and informed else jnp.ones(GROUP_COUNT)
    group = inspection_group(theta, x, q, holding)
    surface = GROUPS[group]
    kind = group % 4
    stand = 0.65 + 0.8 * jax.nn.sigmoid(theta[12:16][kind])
    target = (
        surface + NORMALS[group] * stand + jnp.array([0.0, 0.0, 0.4 * jnp.tanh(theta[16:20][kind])])
    )
    # Optional upstream measurement visit; it occupies real simulated time.
    probe = PROBE_SECONDS * jnp.maximum(jnp.tanh(theta[20]), 0.0)
    survey = jnp.array([3.0, 0.0, 6.5]) if SENSOR_POLICY == "janus" else jnp.array([3.0, -2.8, 4.5])
    target = jnp.where(time < probe, survey, target)
    _, var = b.predict(target)
    sigma = jnp.sqrt(var) if informed else 0.0
    # Predict the same clearance correction used in actual execution. It is a
    # finite handling margin, not a safety theorem: contacts are still measured.
    safe_radius = RADIUS + BODY_RADIUS + HANDLING_CLEARANCE + 3.5 * sigma
    if GEOMETRY == "connected":
        center = jnp.array([jnp.clip(target[0], STRUCTURES[0, 0], STRUCTURES[-1, 0]), 0.0])
        delta = target[:2] - center
        length = jnp.linalg.norm(delta)
        target = target.at[:2].set(
            center + delta / jnp.maximum(length, 1e-6) * jnp.maximum(length, safe_radius)
        )
        target = connected_waypoint(x[:3], target, safe_radius)
    else:
        for center in STRUCTURES:
            delta = target[:2] - center
            length = jnp.linalg.norm(delta)
            xy = center + delta / jnp.maximum(length, 1e-6) * jnp.maximum(length, safe_radius)
            target = target.at[:2].set(xy)
    delta = target - x[:3]
    vmax = 0.65 + 0.35 * jax.nn.sigmoid(theta[21])
    desired = delta * 0.85
    desired *= jnp.minimum(1.0, vmax / jnp.maximum(jnp.linalg.norm(desired), 1e-5))
    # Tangent guidance around the nearest structure blocking the geometric
    # segment. The continuously optimized tie direction chooses a route side.
    to_goal = target[:2] - x[:2]
    to_centers = STRUCTURES - x[:2]
    along = (to_centers @ to_goal) / jnp.maximum(to_goal @ to_goal, 1e-6)
    foot = x[:2] + jnp.clip(along, 0.0, 1.0)[:, None] * to_goal
    blocking = (
        (along > 0.0) & (along < 1.0) & (jnp.linalg.norm(foot - STRUCTURES, axis=1) < safe_radius)
    )
    distances = jnp.linalg.norm(to_centers, axis=1)
    nearest = jnp.argmin(jnp.where(blocking, distances, jnp.inf))
    toward = to_centers[nearest]
    d = distances[nearest]
    cross = toward[0] * to_goal[1] - toward[1] * to_goal[0]
    side = jnp.where(jnp.abs(cross) > 0.05, jnp.sign(cross), jnp.where(theta[22] >= 0.0, 1.0, -1.0))
    angle = jnp.arctan2(toward[1], toward[0]) + side * (
        jnp.arcsin(jnp.minimum(safe_radius / jnp.maximum(d, 1e-5), 1.0)) + 0.08
    )
    tangent = vmax * jnp.array([jnp.cos(angle), jnp.sin(angle)])
    outward = -toward / jnp.maximum(d, 1e-5) * jnp.maximum(safe_radius + 0.1 - d, 0.0) * 1.4
    avoid = tangent + outward
    if GEOMETRY != "connected":
        desired = desired.at[:2].set(jnp.where(jnp.any(blocking), avoid, desired[:2]))
    R = rotation(x[3:6])
    ground = R @ x[6:9]
    acc = 1.3 * (desired - ground)
    look = surface - x[:3]
    yaw = jnp.arctan2(look[1], look[0])
    pitch = jnp.clip(-jnp.arctan2(look[2], jnp.linalg.norm(look[:2])), -0.45, 0.45)
    error = jnp.array([-x[3], pitch - x[4], jnp.arctan2(jnp.sin(yaw - x[5]), jnp.cos(yaw - x[5]))])
    desired_acc = jnp.r_[R.T @ acc - jnp.cross(x[9:12], x[6:9]), 4.0 * error - 3.0 * x[9:12]]
    field = (lambda p: weights(p) @ b.mean) if informed else (lambda p: jnp.zeros(3))
    wrench = (MR + MA) * desired_acc + environmental_wrench(x, field)
    return allocate_thrusters(wrench)


def camera_quality(x):
    offset = TARGETS - x[:3]
    distance = jnp.linalg.norm(offset, axis=1)
    direction = offset / jnp.maximum(distance[:, None], 1e-6)
    forward = rotation(x[3:6])[:, 0]
    angle = jnp.maximum(direction @ forward, 0.0) ** 12
    # Panels face the front water corridor, hence back-side views count zero.
    facing = jnp.maximum(-jnp.sum(direction * jnp.repeat(NORMALS, 4, axis=0), axis=1), 0.0) ** 2
    stand = jnp.exp(-0.5 * ((distance - 1.0) / 0.6) ** 2)
    blur = 1 / (1 + 3.0 * jnp.linalg.norm(x[9:12]) ** 2 + 0.5 * jnp.linalg.norm(x[6:9]) ** 2)
    # Reject rays occluded by any of the three full-height structures.
    segment = TARGETS[:, :2] - x[:2]
    relative = STRUCTURES[None, :, :] - x[None, None, :2]
    t = jnp.einsum(
        "tci,ti->tc", jnp.broadcast_to(relative, (len(TARGETS), len(STRUCTURES), 2)), segment
    ) / jnp.maximum(jnp.sum(segment**2, axis=1)[:, None], 1e-6)
    closest = x[None, None, :2] + jnp.clip(t, 0.0, 1.0)[:, :, None] * segment[:, None, :]
    blocked = jnp.any(
        (jnp.linalg.norm(closest - STRUCTURES[None, :, :], axis=2) < RADIUS - 0.01)
        & (t > 0.0)
        & (t < 0.995),
        axis=1,
    )
    if GEOMETRY == "connected":
        blocked = (
            jax.vmap(lambda point: capsule_segment_distance(x[:2], point))(TARGETS[:, :2])
            < RADIUS - 0.01
        )
    return jnp.where(blocked, 0.0, 2.0 * angle * facing * stand * blur)


def initial_state():
    return jnp.r_[jnp.array([-2.0, -4.0, START_DEPTH, 0.0, 0.0, 0.4]), jnp.zeros(15)]


def rollout(
    theta,
    x0,
    q0,
    b0,
    field_values,
    noise,
    seconds=20.0,
    anticipate=True,
    blind=False,
    dt=0.1,
    substeps=5,
    clock=0.0,
    controller_update="all",
    measurement_start=0.0,
):
    # In execution blind=False for every method; only planning differs.
    values = jnp.zeros_like(field_values) if blind else field_values
    nominal = CurrentBelief(jnp.zeros_like(b0.mean), jnp.zeros_like(b0.covariance))

    def controller_belief(b):
        if blind:
            return nominal
        if controller_update == "mean_only":
            return CurrentBelief(b.mean, b0.covariance)
        if controller_update == "covariance_only":
            return CurrentBelief(b0.mean, b.covariance)
        return b

    def tick(carry, item):
        x, q, b, cost, alive, holding = carry
        i, eps = item
        active = alive
        command = control(
            theta,
            x,
            q,
            controller_belief(b),
            i * dt + clock,
            informed=not blind,
            holding=holding,
        )
        xn = jax.lax.fori_loop(
            0, substeps, lambda _, state: step(state, command, values, dt / substeps), x
        )
        xn = jnp.where(active, xn, x)
        gap = clearance(xn[:3])
        alive = alive & (gap >= 0.0) & (jnp.max(jnp.abs(xn[3:5])) < 1.2) & jnp.isfinite(xn).all()
        C = camera_quality(xn)
        qn = jnp.clip(
            q + dt * (jnp.where(active, C**2 / 0.3 * (1 - q) ** 2, 0.0) - 0.016 * q**2), 0.0, 1.0
        )
        if anticipate:
            measured = (
                (i % round(0.5 / dt) == round(0.5 / dt) - 1)
                & alive
                & (i * dt + clock >= measurement_start)
            )
            b = jax.lax.cond(
                measured,
                lambda old: observe_and_update(old, xn, values, eps),
                lambda old: old,
                b,
            )
            if (
                BELIEF_RECOURSE
                and not blind
                and controller_update not in ["covariance_only", "choice_frozen"]
            ):
                holding = jax.lax.cond(
                    measured,
                    lambda _: holding_quality(controller_belief(b)),
                    lambda _: holding,
                    operand=None,
                )
        increment = dt * (jnp.mean(jnp.maximum(0.75 - qn, 0.0)) + 0.000002 * (xn[20] - x[20]) / dt)
        # Failure freezes motion; unobserved targets still accrue task deficit.
        cost += increment
        mean, var = b.predict(xn[:3])
        return (xn, qn, b, cost, alive, holding), (
            xn,
            qn,
            b.mean,
            jnp.sqrt(jnp.maximum(jnp.mean(jnp.diag(b.covariance).reshape(N, 3), axis=1), 0.0)),
            command,
            gap,
            cost,
            mean,
            jnp.sqrt(var),
            jnp.ones(4, dtype=bool) if SENSOR_POLICY == "continuous" else beam_operator(xn)[1],
            holding,
        )

    result, trace = jax.lax.scan(
        tick,
        (
            x0,
            q0,
            b0,
            jnp.array(0.0),
            jnp.array(True),
            holding_quality(controller_belief(b0)) if BELIEF_RECOURSE else jnp.ones(GROUP_COUNT),
        ),
        (jnp.arange(round(seconds / dt)), noise),
    )
    return result[3] + 40.0 * (~result[4]), (result[:5], trace)
