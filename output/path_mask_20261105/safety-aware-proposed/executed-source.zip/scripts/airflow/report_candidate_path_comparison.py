"""Summarize all fresh matched runs without selecting away failures."""
import argparse,gzip,hashlib,json
from pathlib import Path
import numpy as np


def distribution(values):
    values=np.asarray(values,float)
    return None if len(values)==0 else dict(count=len(values),median_s=float(np.median(values)),
        p95_s=float(np.quantile(values,.95)),max_s=float(values.max()))


def read_run(path):
    with gzip.open(path,'rt') as stream:r=json.load(stream)
    summary=r['summary'];warm=[p for p in r['plans'] if p['phase']=='monitoring' and not p['compilation_included']]
    pos=np.asarray(r['samples']);distance=np.linalg.norm(np.diff(pos[:,1:3],axis=0),axis=1)
    gate=summary['gate_time_s']
    phases=np.array([v[0] for v in r['samples'][1:]])
    method=path.name.split('-')[-1].split('.')[0]
    stats=dict(source=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        scenario=r['scenario'],method=method,**summary,
        learning_distance_m=float(distance[phases<=gate].sum()) if gate is not None else float(distance.sum()),
        total_distance_m=float(distance.sum()),
        timing={k:distribution([p['timing'][k] for p in warm if k in p['timing']])
            for k in ('posterior','safety_belief_refresh','fields','geometry','optimization')},
        search=distribution([p['validation']['search_s'] for p in warm]),
        validation=distribution([p['validation']['validation_s'] for p in warm]),
        request=distribution([sum(v for k,v in p['timing'].items() if k not in ('posterior','safety_belief_refresh')) for p in warm]),
        update_and_request=distribution([p['wall_seconds'] for p in warm]),
        relaxed_selected_plans=sum(not p['validation'].get('safety_feasible',[True]*len(p['validation']['feasible']))[p['validation']['selected']]
            for p in r['plans'] if p['phase']=='monitoring'),
        hold_fallbacks=sum(bool(p.get('execution_fallback')) for p in r['plans'] if p['phase']=='monitoring'))
    return stats


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,default=Path('output/path_mask_20261105'))
    args=parser.parse_args();runs=[]
    for folder in ('safety-aware-baseline','safety-aware-proposed'):
        runs.extend(read_run(p) for p in sorted((args.root/folder).glob('s*-center-*.json.gz')))
    comparisons=[]
    for s in (1,2):
        members=[r for r in runs if r['scenario']==s]
        if len(members)!=2:continue
        baseline=next(r for r in members if r['method']=='baseline1');proposed=next(r for r in members if r['method']=='pathmask')
        matched=all(r['completed'] for r in members) and abs(baseline['simulated_seconds']-proposed['simulated_seconds'])<1e-8
        comparisons.append(dict(scenario=s,complete_matched_pair=matched,
            learning_time_saved_s=baseline['survey_duration_s']-proposed['survey_duration_s'] if matched else None,
            monitoring_cost_reduction_fraction=1-proposed['integrated_deficit']/baseline['integrated_deficit'] if matched else None,
            contacts=sum(r['contact'] is not None for r in members),
            both_visit_A=all(r['first_visit_s']['A'] is not None for r in members),
            claimed_success=matched and all(r['contact'] is None for r in members)
                and proposed['survey_duration_s']<baseline['survey_duration_s']
                and proposed['integrated_deficit']<baseline['integrated_deficit']
                and all(r['first_visit_s']['A'] is not None for r in members)))
    report=dict(runs=runs,comparisons=comparisons,
        counts=dict(recorded=len(runs),completed=sum(r['completed'] for r in runs),contacts=sum(r['contact'] is not None for r in runs),
            stopped_without_contact=sum(not r['completed'] and r['stop_reason'] is not None and r['contact'] is None for r in runs)),
        scope='All fresh declared center-in-B trials; no run is removed based on outcome. Earlier diagnostics remain separately archived.',
        comparison='Same initial state, physical model, observation-noise seed, POAM, full uncertainty, MBD and execution filter. Baseline survey + 300 s versus equal proposed total time; all survey monitoring cost counts.',
        limitations=['Different global RMSE and task-posterior stopping domains; both must pass the same finite task-cost validation.',
            'A successful example is not a collision-free guarantee or evidence across all initial conditions.',
            'Finite wind sampling and possible model misspecification remain; infeasible commands and collisions are reported.',
            'Warm request timing excludes compilation; update-and-request includes the preceding POAM update and safety-field refresh.'])
    temporary=args.root/'safety-aware-results.json.tmp'
    temporary.write_text(json.dumps(report,indent=2,allow_nan=False));temporary.replace(args.root/'safety-aware-results.json')
    print(json.dumps(dict(counts=report['counts'],comparisons=comparisons)))


if __name__=='__main__':main()
