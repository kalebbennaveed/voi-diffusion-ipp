"""Original POAM pivoted-Cholesky inducing selection for executed learning.

The previous observed-slot allocator is not used. Preserve the full transported
statistics, attentive kernel, residual covariance, noise, and prior amplitude.
"""
import jax
import jax.numpy as jnp
import jax.scipy as jsp
from voi_diffusion_ipp.wind.poam import (select_inducing_jax,attention_weights,
    chol_solve,transport_statistic_root,variational_from_root,negative_elbo,attentive_kernel)


@jax.jit
def condition(b,positions,measurements,mask):
    centers=select_inducing_jax(b.basis.parameters,jnp.concatenate((b.basis.centers,positions)),b.basis.lengths,len(b.mean))
    K=b.kernel(centers,centers)
    # Selecting only old locations can permute them. Apply exact permutation
    # transport instead of introducing repeated numerical regularization.
    equal=jnp.all(b.basis.centers[:,None,:]==centers[None,:,:],axis=-1)
    same_set=jnp.all(jnp.any(equal,axis=0))
    P=jax.lax.cond(same_set,lambda _:equal.astype(K.dtype),
        lambda _:chol_solve(b.old_K,b.kernel(b.basis.centers,centers)),None)
    Kuf=b.kernel(centers,positions)
    a=P.T@b.a+Kuf@measurements;root=transport_statistic_root(b.root_B,P,Kuf)
    mean,cov=variational_from_root(K,a,root,b.noise_std)
    basis=b.basis._replace(centers=centers,center_weights=attention_weights(b.basis.parameters,centers))
    supported=(equal.T@mask.astype(jnp.int32)>0)|jnp.any(jnp.linalg.norm(centers[:,None]-positions[None],axis=-1)<=.15,axis=1)
    return b._replace(basis=basis,mean=mean,covariance=(cov+cov.T)/2,a=a,B=root@root.T,root_B=root,
                      old_K=K,inverse=chol_solve(K,jnp.eye(len(K)))),supported


@jax.jit
def train(b,bx,by,data_count,m,v,step):
    """Existing POAM variational EM objective; four Adam steps on actual data.

    Follow the M step with an observation-free transported E step so all saved
    prediction and sampling caches correspond to the updated kernel.
    """
    def update(carry,_):
        params,m,v,step=carry
        loss,g=jax.value_and_grad(negative_elbo)(params,bx,by,b.basis.centers,
            b.mean,b.covariance,b.basis.lengths,b.noise_std,data_count)
        step=step+1;m=jax.tree.map(lambda a,g:.9*a+.1*g,m,g)
        v=jax.tree.map(lambda a,g:.999*a+.001*g*g,v,g)
        params=jax.tree.map(lambda p,m,v:p-.001*(m/(1-.9**step))/(jnp.sqrt(v/(1-.999**step))+1e-8),params,m,v)
        return (params,m,v,step),loss
    (params,m,v,step),loss=jax.lax.scan(update,(b.basis.parameters,m,v,step),None,length=4)
    z=b.basis.centers;kernel=lambda x,y:attentive_kernel(params,x,y,b.basis.lengths)
    K=kernel(z,z);P=chol_solve(b.old_K,K);a=P.T@b.a
    root=transport_statistic_root(b.root_B,P,jnp.zeros((len(z),0)))
    mean,cov=variational_from_root(K,a,root,b.noise_std)
    support=b.basis.support;Ks=kernel(support,support)
    L=jnp.linalg.cholesky((Ks+Ks.T)/2+1e-4*jnp.eye(len(support)))
    inverse=jsp.linalg.cho_solve((L,True),jnp.eye(len(support)))
    basis=b.basis._replace(parameters=params,center_weights=attention_weights(params,z),
        support_weights=attention_weights(params,support),support_inverse=inverse,support_cholesky=L)
    return b._replace(basis=basis,mean=mean,covariance=(cov+cov.T)/2,a=a,B=root@root.T,root_B=root,
        old_K=K,inverse=chol_solve(K,jnp.eye(len(K)))),m,v,step,loss
