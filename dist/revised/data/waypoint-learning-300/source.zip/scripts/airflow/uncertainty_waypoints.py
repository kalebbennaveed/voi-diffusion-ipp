"""Wind-variance waypoints with a geometric path; RPCBF filters all execution.

No MBD, clarity objective, hidden wind, synthetic measurements, or route labels
are inputs to this policy. The posterior is changed by the sensor adapter only.
"""
import numpy as np
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import dijkstra
from monitoring_routes import clearance, visible


class WaypointPolicy:
    def __init__(self, env, spacing=.125, margin=.10, speed=.4):
        self.ob=np.asarray(env.obstacles); self.bounds=np.asarray(env.bounds)
        self.margin=margin; self.speed=speed
        nx,ny=np.rint((self.bounds[1]-self.bounds[0])/spacing).astype(int)
        xx,yy=np.meshgrid(self.bounds[0,0]+(np.arange(nx)+.5)*spacing,
                          self.bounds[0,1]+(np.arange(ny)+.5)*spacing)
        self.nodes=np.c_[xx.ravel(),yy.ravel()]
        self.free=clearance(self.nodes,self.ob,self.bounds)>=margin
        ids=np.arange(nx*ny).reshape(ny,nx); rr=[];cc=[];ww=[]
        for di,dj in [(1,0),(0,1),(1,1),(-1,1)]:
            j0=max(0,-dj);j1=min(ny,ny-dj);i0=max(0,-di);i1=min(nx,nx-di)
            a=ids[j0:j1,i0:i1].ravel();b=ids[j0+dj:j1+dj,i0+di:i1+di].ravel()
            ok=self.free[a]&self.free[b]&visible(self.nodes[a],self.nodes[b],self.ob,self.bounds,margin)
            a=a[ok];b=b[ok];rr.extend([a,b]);cc.extend([b,a]);ww.extend([np.full(len(a),spacing*np.hypot(di,dj))]*2)
        self.rows=np.concatenate(rr);self.cols=np.concatenate(cc);self.weights=np.concatenate(ww)
        self.graph=csr_matrix((self.weights,(self.rows,self.cols)),shape=(nx*ny,nx*ny))
        self.target=None;self.path=None;self.selected_at=0.;self.start_distance=0.
        self.cooldown=np.zeros(len(self.nodes))

    def plan(self, x, variance, clock, wind_mean=None):
        """Choose a high-variance reachable waypoint with travel regularization.

        Candidate score sigma^2/(1+L/1m); exclude within .35m of current
        position. Persist until arrival, substantial learning at the target,
        or measured lack of progress. Stalled targets get a temporary cooldown;
        this is an execution recovery rule, not fictitious wind information.
        """
        p=np.asarray(x[:2]);variance=np.asarray(variance)
        order=np.flatnonzero(self.free);order=order[np.argsort(np.linalg.norm(self.nodes[order]-p,axis=1))]
        connected=order[visible(p,self.nodes[order],self.ob,self.bounds,0.)]
        if not len(connected):return np.array([p]),dict(reason='no geometric connection',target=p.tolist())
        start=int(connected[0]);graph=self.graph
        excluded=0
        if wind_mean is not None:
            # Exact existing wind-force mapping at the proposed edge velocity.
            # A nominal actuator-feasibility screen, not a safety certificate:
            # full posterior uncertainty still enters execution RPCBF unchanged.
            wind_mean=np.asarray(wind_mean)
            direction=(self.nodes[self.cols]-self.nodes[self.rows])/self.weights[:,None]
            velocity=self.speed*direction
            relative=wind_mean[self.rows]-velocity
            force=(.1/.680)*np.linalg.norm(relative,axis=1)[:,None]*relative
            relative_end=wind_mean[self.cols]-velocity
            force_end=(.1/.680)*np.linalg.norm(relative_end,axis=1)[:,None]*relative_end
            allowed=(np.maximum(np.abs(force),np.abs(force_end)).max(axis=1)<1.2)
            excluded=int((~allowed).sum())
            graph=csr_matrix((self.weights[allowed],(self.rows[allowed],self.cols[allowed])),shape=self.graph.shape)
        dist,pred=dijkstra(graph,indices=start,return_predecessors=True)
        reason='persistent target'
        if self.target is not None:
            reached=np.linalg.norm(p-self.nodes[self.target])<.18
            learned=variance[self.target]<.25
            stalled=clock-self.selected_at>=15 and self.start_distance-dist[self.target]<.3
            if reached or learned or stalled or not np.isfinite(dist[self.target]):
                if stalled:self.cooldown[np.linalg.norm(self.nodes-self.nodes[self.target],axis=1)<.5]=clock+30
                reason='arrived' if reached else 'target learned' if learned else 'stalled target cooldown'
                self.target=None
        if self.target is None:
            score=variance/(1+dist)
            score[~self.free|~np.isfinite(dist)|(np.linalg.norm(self.nodes-p,axis=1)<.35)|(self.cooldown>clock)]=-np.inf
            if not np.isfinite(score).any():return np.array([p]),dict(reason='no eligible waypoint',target=p.tolist())
            self.target=int(np.argmax(score));self.selected_at=clock;self.start_distance=dist[self.target]
        route=[self.target]
        while route[-1]!=start:
            previous=int(pred[route[-1]])
            if previous<0:raise RuntimeError('Unreachable waypoint selected')
            route.append(previous)
        raw=np.vstack([p,self.nodes[route[::-1]]]);path=[raw[0]];i=0
        while i<len(raw)-1:
            valid=np.flatnonzero(visible(raw[i],raw[i+1:],self.ob,self.bounds,self.margin))
            if wind_mean is not None:
                # Do not let visibility pruning cut across excluded wind cells.
                # A short local chord stays within the accepted grid corridor.
                valid=valid[valid<=2]
            j=i+1+(int(valid[-1]) if len(valid) else 0);path.append(raw[j]);i=j
        self.path=np.asarray(path)
        return self.path,dict(reason=reason,target=self.nodes[self.target].tolist(),
            target_variance=float(variance[self.target]),path_length_m=float(dist[self.target]),
            score=float(variance[self.target]/(1+dist[self.target])),selected_at=self.selected_at,
            wind_infeasible_edges=excluded)

    def reference(self, x, path):
        """A local velocity reference, replanned from measured state every .2s.

        The double integrator is unchanged. This is an ordinary waypoint
        tracking setpoint; the existing feedback and full RPCBF compute u.
        """
        p=np.asarray(x[:2]);path=np.asarray(path)
        target=path[min(1,len(path)-1)]
        delta=target-p;distance=np.linalg.norm(delta)
        speed=min(self.speed,1.0*distance)
        velocity=delta/max(distance,1e-12)*speed
        return np.r_[p,velocity]
