"""Separate learn-then-MBD experiment: full posterior, guarded execution.

The oracle RMSE gate lives in the experiment runner, outside these APIs.
No true field is accepted by this planner or control law.
"""
from implicit_monitoring_v3 import *
import implicit_monitoring_v2 as core
import implicit_monitoring_v3 as old


def field_builder(points,shape,cfg):
    @jax.jit
    def build(b,count,performance_key,safety_key):
        def draw(key,n):
            eps=jax.random.normal(key,(n//2,*b.sample_shape),dtype=b.mean.dtype)
            coeff=b.sample_coefficients(jnp.concatenate((eps,-eps)))
            return jax.vmap(lambda c:b.basis.evaluate(points,c))(coeff).reshape(n,*shape)
        mu,cov=b.predict(points)
        return Tables(mu.reshape(shape),jnp.sqrt(cov[:,0,0]).reshape(*shape[:2],1),
            jnp.ones((*shape[:2],1)),draw(performance_key,cfg.worlds),
            draw(safety_key,cfg.construction_worlds),
            draw(jax.random.fold_in(performance_key,104729),cfg.validation_worlds))
    return build


def boundary_constraints(x,mean,std_table,basis,env,cfg):
    """Robust relative-degree-two boundary CBF, exact aerodynamic bound.

    h = distance to a wall minus margin; h''+2λh'+λ²h >= 0.
    Conditional on initial h,h'+λh >= 0 and a valid disturbance envelope,
    this supplies an independent wall-braking constraint. It does not certify
    finite sampling, posterior calibration, or an infeasible actuator problem.
    """
    normal=jnp.array([[1.,0.],[-1.,0.],[0.,1.],[0.,-1.]])
    h=jnp.array([x[0]-env.bounds[0,0],env.bounds[1,0]-x[0],
                 x[1]-env.bounds[0,1],env.bounds[1,1]-x[1]])-cfg.safety_margin
    sigma=jnp.maximum(basis.evaluate(x[:2],std_table)[0,0],0.)
    radius=3*jnp.sqrt(sigma**2+.1**2)
    A=-normal;rate=1.5
    b=2*rate*(normal@x[2:])+rate**2*h-core.force_support(A,x[2:],mean.mean_at(x[:2])[0],radius)
    return A,b


def control(x,nominal,mean,fields,std_table,basis,env,cfg,hard=False):
    grad,B,bound=core.constraints(x,mean,fields,std_table,basis,env,cfg)
    wall_A,wall_b=boundary_constraints(x,mean,std_table,basis,env,cfg)
    A=jnp.concatenate((grad[:,2:],wall_A));b=jnp.concatenate((bound,wall_b))
    if hard:
        sol=solve(nominal,A,b,cfg.umax,design_policy(x,mean,cfg))
        return sol.control,FilterInfo(B,grad,jnp.linalg.norm(sol.control-nominal),
            sol.feasible,sol.slack,sol.residual,jnp.array(0.))
    u,slack=soft_projection(nominal,A,b,cfg.umax,cfg.slack_weight)
    return u,jnp.max(slack)


def execution_block(env,cfg,pcfg,basis,seconds=.2):
    return core.execution_block(env,cfg,pcfg,basis,seconds,control_fn=control)


def optimizer(env,cfg,basis,aware=True):
    """Original independent MBD chains; validate optimized mode leaders.

    Retain the existing two-finalist compute budget. Unlike the earlier
    baseline, the second candidate is an optimized mode leader, not merely
    an unoptimized geometric seed. Hold is a separately logged fallback.
    """
    import time
    @jax.jit
    def optimize(x,q,tables,seeds,previous,key):
        def evaluate(theta):
            r=jax.vmap(lambda w:old.rollout(theta,x,q,tables,w,basis,env,cfg,aware,control))(tables.planning)
            return jnp.where(r.terminated,jnp.inf,r.monitor+r.penalty)
        result=search(evaluate,seeds,previous,key,cfg,jnp.array(1.),jnp.array(0.),jnp.array(False))
        leaders=result.finalists[:cfg.mode_count]
        leader_cost=jax.vmap(evaluate)(leaders).mean(axis=1)
        return result,leader_cost
    @jax.jit
    def validate(theta,x,q,tables):
        return jax.vmap(lambda w:core.execution_forecast(theta,x,q,tables,w,basis,env,cfg,aware,control))(tables.validation)
    def plan(x,q,tables,seeds,previous,key):
        t=time.perf_counter();(result,leader_cost)=optimize(x,q,tables,seeds,previous,key);jax.block_until_ready(leader_cost)
        search_s=time.perf_counter()-t
        # Global winner and the best different mode leader, under training cost.
        params=np.asarray(result.finalists[:cfg.mode_count])
        scores=np.asarray(leader_cost)
        distinct=np.any(params!=np.asarray(result.final)[None],axis=1)
        order=np.argsort(np.where(distinct,scores,np.inf))
        second=params[order[0]] if np.any(distinct) else np.asarray(seeds[0])
        candidates=[result.final,jnp.asarray(second)];origins=['MBD global winner','MBD alternate mode leader']
        forecasts=[];seen={};t=time.perf_counter()
        for theta in candidates:
            token=np.asarray(theta).tobytes()
            if token not in seen:
                seen[token]=validate(theta,x,q,tables);jax.block_until_ready(seen[token])
            forecasts.append(seen[token])
        def arrays():
            ff=jax.tree.map(lambda *v:jnp.stack(v),*forecasts)
            cost=jnp.mean(ff.monitor+ff.penalty,axis=1)
            valid=jnp.all(~ff.terminated&(ff.max_slack<1e-4),axis=1)&jnp.isfinite(cost)
            return ff,cost,valid
        ff,cost,valid=arrays()
        if not bool(jnp.any(valid)):
            hold=validate(seeds[0],x,q,tables);jax.block_until_ready(hold)
            candidates.append(seeds[0]);origins.append('hold fallback');forecasts.append(hold)
            ff,cost,valid=arrays()
        choice=int(jnp.argmin(jnp.where(valid,cost,jnp.inf))) if bool(jnp.any(valid)) else len(candidates)-1
        audit=dict(leader_reevaluations=cfg.mode_count,leader_costs=leader_cost,candidates=jnp.stack(candidates),costs=cost,feasible=valid,
            contacts=ff.terminated,slack=ff.max_slack,selected=choice,no_feasible=~jnp.any(valid),
            unique_evaluations=len(seen)+(len(candidates)>2),search_s=search_s,validation_s=time.perf_counter()-t)
        return candidates[choice],cost[choice],result,jax.tree.map(lambda z:z[choice],ff),audit
    return plan
