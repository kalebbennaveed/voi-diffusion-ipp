# Airflow experiment status

The initial `scenario*_n64`, `scenario*_n128`, `scenario2_n192`, and
`openmp_check` runs are **superseded and must not be used as validated fields**.
An audit found Bouzidi links at junctions without the required second fluid
node. Their original source is retained as `source_initial.py` for traceability.
The incomplete 192-cell transient run was stopped.

The corrected `stationary_s*_n*` runs use the library-documented halfway
no-slip treatment for those specific links and record their counts. Molecular
viscosity, the physical geometry, inlet conditions, and the turbulence model
are unchanged. Exported horizontal slices now interpolate at exactly 0.75 m.

The user requires a wind field that is constant in time. The website therefore
uses one fixed **vector mean** from each corrected CFD run, never a sequence
of changing fields. This is a stationary mean-flow environment, not a claim
that instantaneous turbulent air is exactly steady. Numerical convergence,
sampling sensitivity, and the numerical wall treatment must remain disclosed.

The corrected 128-cell Scenario 2 run failed its numerical stability gate.
It is excluded from the webpage; see `refinement_failure.json`. Both displayed
fields retain the completed 64-cell computations for a consistent comparison.
They are provisional and are not certified as an accurate physical wind model.
