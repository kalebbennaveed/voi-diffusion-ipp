"""Independent checks of the deterministic specialization and batched execution."""
import json
from pathlib import Path
import signal
import sys
import time
from dataclasses import replace
import numpy as np
ROOT=Path(__file__).resolve().parents[3]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'scripts/airflow')]
signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('90 s check limit')))
signal.alarm(90);started=time.perf_counter()
import jax
import jax.numpy as jnp
import known_monitoring as known
import legacy_monitoring as legacy
import monitoring_mbd as m
from voi_diffusion_ipp.wind.oracle import KnownWind,KnownBasis
from voi_diffusion_ipp.safety.flow_policy_value import filter_control

cfg=known.settings();pcfg=replace(legacy.physical_settings(cfg),safety_margin=cfg.safety_margin,inner_samples=1)
env,_=m.environment(pcfg);checks=[]
field=m.physical.load_wind(2);belief=KnownWind(KnownBasis(field))
raw=np.load(ROOT/'results/airflow/known_wind_300_20261103/s2-aware-plan-003.npz')
x=jnp.asarray(raw['initial_state']);q=jnp.asarray(raw['initial_clarity']);theta=jnp.asarray(raw['theta'],jnp.float64)
nom=jnp.array([.8,-.4]);single=belief.inner_fields(jnp.zeros((1,1,2)));eight=belief.inner_fields(jnp.zeros((8,1,2)))
filtered=jax.jit(lambda inner:filter_control(x,nom,belief,inner,env,pcfg))
one=filtered(single);many=filtered(eight);jax.block_until_ready(many)
assert np.allclose(one[0],many[0],rtol=0,atol=1e-10)
assert np.allclose(one[1].value,many[1].value,rtol=0,atol=1e-10)
checks.append(dict(name='One known field equals eight identical construction fields',control_error=float(np.max(abs(np.asarray(one[0]-many[0]))))))

# Existing scalar execution kernel driven by the original runner's reference
# scheduling, versus the new compiled block. No model is reimplemented here.
block=known.execution_block(env,cfg,pcfg);end,rows=block(x,q,theta,field,jnp.array(True));jax.block_until_ready(end)
scalar=m.execution_kernel(env,pcfg);refs,aa=legacy.old.nominal_reference(theta,x,cfg)
xx,qq,alive=x,q,jnp.array(True);states=[];qs=[];controls=[]
for k in range(round(cfg.commit/pcfg.execution_dt)):
    local=k*pcfg.execution_dt;i=min(int(round(local/cfg.dt,8)),cfg.steps-1);off=local-i*cfg.dt
    ref,a=refs[i],aa[i];reference=jnp.r_[ref[:2]+off*ref[2:]+.5*off*off*a,ref[2:]+off*a]
    nominal=m.tracking_control(xx,reference,a,belief,pcfg,True)
    result,u,info=scalar(xx,qq,nominal,belief,single,field,alive)
    xx,qq,alive=result[:3];states.append(np.asarray(xx));qs.append(np.asarray(qq));controls.append(np.asarray(u))
errors={name:float(np.max(abs(np.asarray(a)-np.asarray(b)))) for name,a,b in [('state',states,rows[0]),('clarity',qs,rows[1]),('control',controls,rows[2])]}
assert max(errors.values())<1e-8,errors
checks.append(dict(name='Compiled commit matches original scalar execution over 100 controls',errors=errors))

# Constant wind is exactly represented by the old C1 table and by FixedWind.
# This verifies the adapter retains the original forecast/clarity objective.
short=replace(cfg,horizon=1.,commit=1.)
constant=jnp.array([.2,-.1]);fixed=m.physical.FixedWind(jnp.broadcast_to(constant,field.grid.shape),field.dx)
table=jnp.broadcast_to(constant,legacy.SHAPE);t=jnp.linspace(-.2,.3,short.steps*2)
new=jax.jit(lambda:known.rollout(t,x,q,fixed,env,short,True))()
old=jax.jit(lambda:legacy.rollout(t,x,q,table,table[None],table,env,short,True))()
jax.block_until_ready(old)
errors={name:float(np.max(abs(np.asarray(getattr(new,name))-np.asarray(getattr(old,name))))) for name in ['x','q','u','monitor','penalty','max_slack','min_clearance']}
assert max(errors.values())<1e-7,errors
checks.append(dict(name='Known-wind adapter equals original forecast for an exactly representable field',errors=errors))
blind=jax.jit(lambda f:known.rollout(t,x,q,f,env,short,False))
a=blind(field);b=blind(fixed);jax.block_until_ready(b)
assert np.array_equal(np.asarray(a.x),np.asarray(b.x)) and float(a.monitor)==float(b.monitor)
checks.append(dict(name='Baseline forecast is independent of supplied physical wind',passed=True))
report=dict(checks=checks,wall_seconds=time.perf_counter()-started)
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
