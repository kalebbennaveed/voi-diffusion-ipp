# Monitoring MBD implementation audit

This experiment uses the two existing stationary CFD fields and circular-obstacle environment. The robot, airflow files, air-force law, POAM implementation, clarity equation and RPCBF modules are unchanged. The comparison is expected-current-belief MBD against still-air MBD with the same wind-aware low-level controller after optimization. There are no anticipated measurements, hypothetical posterior updates, optimistic/tail objectives, or information bonuses.

## Decision variables and diffusion

The decision is 300 independent nominal acceleration coordinates: two axes at 0.2 s intervals over 30 s. A nominal double-integrator reference is integrated exactly. The original PD reference tracker uses gains 3/0.680 and 5/0.680, plus current-mean air-force compensation. Both methods use this controller during execution; baseline prediction uses still air and no planning filter.

`planning/mbd.py` retains the original Gaussian proposal, cost-weighted score and reverse update from Pan et al., *Model-Based Diffusion for Trajectory Optimization*, equations 6, 8 and 9. The target is proportional to exp(-J/0.025) on the latent box [-8,8]^300. Proposals remain Gaussian; samples outside the target domain receive zero weight. Physical reference accelerations use 1.6*tanh(theta). No Gaussian sample clipping is substituted for rejection.

Eight independent reverse chains retain all starting trajectories as incumbents. Four diffusion levels distribute 16 total proposals per level equally across the chains. Each planning call evaluates 88 full objectives, including the separate initial-cost diagnostics. Every coordinate remains free. This is a finite search budget, not a convergence guarantee.

## Coarse initialization

At every planning call, a 64 by 37 grid is rebuilt from analytic circle and wall geometry. Exact no-sensing clarity decay and approximate Gaussian-footprint scoring rank candidate destinations. Compiled Dijkstra supplies four spatially distinct destinations and two alternative passages to a distant destination; hold and shifted continuation complete the eight starts. No named-region destination, offline graph or true wind is supplied to this initializer.

A regression was found at the central approach: thin edge penalties and unrestricted visibility pruning could produce multiple curves through the same passage. Temporary cuts across geometrically discovered bottlenecks now diversify the graph searches, and visibility pruning respects those cuts. These cuts affect initialization only; they never become physical obstacles or RPCBF constraints.

The initializer retimes rounded geometric paths into bounded nominal double-integrator reference accelerations. Retiming fallbacks are explicitly recorded. The approximate coarse ranking is never used as the final planning objective. An end-to-end benchmark, including graph construction, scoring, search, path recovery and retiming, is in `results/airflow/coarse_initialization_benchmark.json`; the requested 5 ms target has not been met.

## Full objective and execution

The full forecast integrates the existing wind-force plant and whole-space clarity ODE with 0.01 s RK4 steps. The aware method averages two coherent current-POAM wind-world draws and applies the original relaxed RPCBF using three separate construction draws, the complete backup rollout and spline extrema. The baseline objective uses still air with no planning filter. The belief stays frozen inside each forecast.

The old study's soft safety costs are restored: max(0.06-clearance,0)^2 + 2*max(speed-3.1,0)^2, integrated while the predicted robot is alive. Planning cost and monitoring-deficit cost are saved separately. The clearance preference uses the current 0.06 m physical margin: the historical 0.6 m threshold was incompatible with these narrow passages. Predicted contact is absorbing: motion and sensing stop, but clarity continues decaying over the entire remaining horizon. A contact never receives a shorter monitoring-cost horizon.

The physical robot obeys p_dot=v and v_dot=u+(0.1/0.680)*norm(w(p)-v)*(w(p)-v), with each control axis bounded by 1.6 m/s^2. Actual hard RPCBF runs at 20 Hz and physics/clarity at 100 Hz. The MPC commitment is the old study's 5 s; POAM assimilates all actual 5 Hz wind observations at each replan, with ten training steps and inducing relocation. The two methods start with the same untrained prior and one noisy local observation; no wind survey or oracle has been inserted.

## Checks and interpretation

36 tests passed, including analytic Gaussian-convolution and independent quadrature checks of MBD, exact independent-chain equivalence, late-state passage preservation, fractional contact and post-contact decay, windy filtered full-rollout cost equivalence, and separate soft-cost accounting. Each saved run is replayed from held controls, and every saved reverse chain is independently checked against the recorded PRNG proposals, score and reverse equations. A held-control 0.005 s numerical refinement is also reported. This local check is not a global reoptimized convergence study.

The historical successful `quarter` experiments used different obstacle geometry, a much wider sensor footprint, different decay and control parameters, and, in one long run, explicit initial wind measurements. Their successful trajectories are evidence for the method structure, not a valid performance prediction for this environment.

Passing implementation checks does not demonstrate a bypass, safe exploration or persistent monitoring of both regions. The displayed runs report actual passage crossings, region visits, clearance, contacts and infeasible filter steps. Cold-start belief error and finite optimization budget must remain visible rather than being hidden by an oracle field or a forced path.
