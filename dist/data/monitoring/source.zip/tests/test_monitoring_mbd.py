"""Scientific contracts for the added frozen-belief monitoring comparison."""
import sys
from pathlib import Path
from dataclasses import replace
import jax
import jax.numpy as jnp
import numpy as np
from scipy.integrate import solve_ivp

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts/airflow'))
import monitoring_mbd as m
from voi_diffusion_ipp.wind.poam import init_parameters,select_inducing


def test_every_free_cell_has_real_process_noise_and_target():
    cfg=m.Settings();env,grid=m.environment(cfg)
    assert len(env.cells)==len(grid['free_indices'])
    assert np.all(np.asarray(env.targets)>0)
    assert np.all(np.asarray(env.process_noise)>0)
    in_regions=grid['membership'].any(axis=1)
    np.testing.assert_array_equal(np.asarray(env.process_noise)[in_regions],cfg.clarity_decay)
    np.testing.assert_array_equal(np.asarray(env.process_noise)[~in_regions],cfg.background_decay)
    assert cfg.clarity_decay/cfg.background_decay>=8


def test_clarity_matches_independent_covariance_riccati_integration():
    cfg=m.Settings();env,_=m.environment(cfg)
    cells=np.array([[1.45,.875],[5.5,3.5],[4.,.4]])
    Q=np.array([.16,.16,.02]);q=np.full(3,.74);p=np.array([1.45,.875])
    env=env._replace(cells=jnp.array(cells),targets=jnp.full(3,.7),process_noise=jnp.array(Q))
    x=jnp.r_[jnp.array(p),jnp.zeros(2)]
    end=m.advance(x,jnp.array(q),jnp.zeros(2),m.StillAir(),env,cfg,True,interval=.2)
    C=np.exp(-np.sum((cells-p)**2,axis=1)/(2*cfg.sensor_sigma**2))
    P0=1/q-1
    oracle=solve_ivp(lambda t,P:Q-C*C/cfg.sensor_R*P*P,(0,.2),P0,method='DOP853',atol=1e-12,rtol=1e-12)
    np.testing.assert_allclose(end[1],1/(1+oracle.y[:,-1]),atol=2e-8)
    dead=m.advance(x,jnp.array(q),jnp.zeros(2),m.StillAir(),env,cfg,False,interval=.2)
    np.testing.assert_allclose(dead[1],q/(1+.2*Q*q),atol=1e-12)


def test_swept_contact_is_not_an_endpoint_only_check():
    env,_=m.environment(m.Settings());center=np.array(env.obstacles[2,:2]);r=float(env.obstacles[2,2])
    a=center+[-r-.1,0];b=center+[r+.1,0]
    t=float(m.contact_fraction(jnp.array(a),jnp.array(b),env))
    np.testing.assert_allclose(a+t*(b-a),center+[-r,0],atol=1e-12)


def test_baseline_forecast_uses_neither_belief_nor_filter():
    cfg=replace(m.Settings(),horizon_seconds=.4,commit_seconds=.4,mission_seconds=.4)
    env,_=m.environment(cfg);env=env._replace(cells=env.cells[:8],targets=env.targets[:8],process_noise=env.process_noise[:8])
    theta=jnp.zeros(cfg.steps*2);x=jnp.array([1.45,.875,0.,0.]);q=jnp.full(8,.74)
    class Forbidden:
        def __getattr__(self,name):raise AssertionError('Baseline consulted wind belief: '+name)
    f=m.forecast(theta,x,q,Forbidden(),Forbidden(),m.StillAir(),env,cfg,False)
    np.testing.assert_allclose(f.states,np.tile(np.array(x),(cfg.steps+1,1)),atol=1e-12)
    assert float(f.max_slack)==0 and not bool(f.collided)


def test_inducing_relocation_accepts_readonly_float64_jax_arrays():
    params=init_parameters(jax.random.PRNGKey(8));points=jnp.array([[0.,0.],[1.,0.],[0.,1.],[1.,1.]],dtype=jnp.float64)
    z=select_inducing(params,points,jnp.array([.3,.8,1.3,1.8]),3)
    assert z.shape==(3,2) and len(np.unique(np.asarray(z),axis=0))==3


def test_same_dynamics_and_original_algorithms_are_composed():
    cfg=m.Settings()
    assert cfg.umax==m.physical.CFG.umax and cfg.safety_margin==m.physical.CFG.safety_margin
    assert cfg.backup_steps==m.physical.CFG.backup_steps and cfg.spline=='full'
    assert cfg.execution_dt==m.physical.DT and cfg.physics_dt==.01
    assert m.optimize.__module__=='voi_diffusion_ipp.planning.mbd'
    assert m.relaxed_rpcbf.__module__=='voi_diffusion_ipp.quarter.filter'
    assert m.filter_control.__module__=='voi_diffusion_ipp.safety.flow_policy_value'
    source=Path(m.__file__).read_text()
    assert '.condition(' not in source and 'cache.tabulate' not in source


def test_early_rejection_objective_matches_full_rollout():
    from voi_diffusion_ipp.wind.oracle import KnownWind,KnownBasis
    cfg=replace(m.Settings(),horizon_seconds=1.,commit_seconds=1.,mission_seconds=1.)
    env,_=m.environment(cfg);env=env._replace(cells=env.cells[:8],targets=env.targets[:8],process_noise=env.process_noise[:8])
    b=KnownWind(KnownBasis(m.StillAir()));inner=b.inner_fields(jnp.zeros((cfg.inner_samples,1,2)))
    outer=b.inner_fields(jnp.zeros((cfg.worlds,1,2)))
    q=jnp.full(8,.74)
    for aware in (False,True):
        for x in (jnp.array([1.45,.875,0.,0.]),jnp.array([.01,.5,-3.,0.])):
            theta=jnp.zeros(cfg.steps*2)
            original=m.forecast(theta,x,q,b,inner,m.StillAir(),env,cfg,aware)
            expected=jnp.where(original.collided,jnp.inf,original.cost)
            actual=m.forecast_cost(theta,x,q,b,inner,outer,env,cfg,aware)
            np.testing.assert_allclose(actual,expected,atol=1e-12)


def test_all_three_transfer_seeds_reach_a_in_full_still_air_plant():
    cfg=m.Settings();env,_=m.environment(cfg)
    x=jnp.array([1.45,.875,0.,0.]);q=jnp.full(len(env.cells),cfg.initial_q)
    seeds=m.seed_bank(x,q,env,cfg)
    small=env._replace(cells=env.cells[:1],targets=env.targets[:1],process_noise=env.process_noise[:1])
    evaluate=jax.jit(lambda theta:m.forecast(theta,x,q[:1],None,None,m.StillAir(),small,cfg,False))
    for index in (3,5,7):
        result=evaluate(seeds[index])
        assert not bool(result.collided)
        assert float(result.min_clearance)>=cfg.safety_margin
        assert np.linalg.norm(np.asarray(result.states[-1,:2])-[6.5,3.525])<.05
