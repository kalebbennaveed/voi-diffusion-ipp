"""Replay exported controls and clarity, and audit paired monitoring inputs."""
import argparse,json,hashlib
from dataclasses import replace
from pathlib import Path
import numpy as np
import jax
import jax.numpy as jnp
import monitoring_mbd as m
from voi_diffusion_ipp.wind.gp import InnerFields,WorldField


def audit_selected_plans(directory,ident,record,cfg,env):
    """Recompute first/last selected forecasts from saved full posterior leaves."""
    aware=record['method']=='aware'
    template=m.estimator(cfg,jax.random.PRNGKey(0)).planning_belief()
    structure=jax.tree_util.tree_structure(template)
    if aware:
        evaluate=jax.jit(lambda theta,x,q,b,inner,outer:jax.vmap(
            lambda coeff:m.forecast(theta,x,q,b,inner,WorldField(outer.basis,coeff),env,cfg,True)
        )(outer.coefficients))
    else:
        evaluate=jax.jit(lambda theta,x,q,b,inner,outer:m.forecast(theta,x,q,None,None,m.StillAir(),env,cfg,False))
    checks=[]
    selected=sorted(set([0,len(record['plans'])-1]))
    for index in selected:
        plan=record['plans'][index]
        raw=np.load(directory/f'{ident}-plan-{index:03d}.npz')
        leaves=[jnp.asarray(raw[k]) for k in sorted(raw.files) if k.startswith('belief_leaf_')]
        belief=jax.tree_util.tree_unflatten(structure,leaves)
        inner=InnerFields(belief.basis,jnp.asarray(raw['inner_coefficients']))
        outer=InnerFields(belief.basis,jnp.asarray(raw['outer_coefficients']))
        result=evaluate(jnp.asarray(raw['theta']),jnp.asarray(raw['initial_state']),
                        jnp.asarray(raw['initial_clarity']),belief,inner,outer)
        xs=np.asarray(result.states);xs=xs if aware else xs[None]
        state_error=float(np.max(np.abs(xs-np.asarray(plan['predicted_states']))))
        assert state_error<=5.1e-7
        cost_error=None
        if plan['valid']:
            assert not np.any(np.asarray(result.collided))
            cost_error=abs(float(np.mean(np.asarray(result.cost)))-plan['expected_cost'])
            assert cost_error<1e-9
        checks.append(dict(cycle=index,time_s=plan['t'],valid=plan['valid'],
                           max_exported_forecast_state_error=state_error,expected_cost_error=cost_error))
    return checks


def audit(directory,site,only=None):
    rows=[]
    for scenario in (1,2):
        protocols=[]
        for method in ('aware','baseline'):
            ident=f's{scenario}-{method}'
            if only and ident not in only:continue
            record=json.loads((directory/(ident+'.json')).read_text())
            protocol=json.loads((directory/(ident+'-protocol.json')).read_text());protocols.append(protocol)
            cfg=m.Settings(**protocol['settings']);env,grid=m.environment(cfg)
            truth=m.physical.load_wind(scenario,site)
            raw=np.load(directory/(ident+'-execution.npz'))
            a=raw['samples'];x=raw['states'];q=raw['clarity'];obs=raw['observation_rows']
            assert record['summary']['completed'] and a[-1,0]==cfg.mission_seconds
            assert np.all(np.isfinite(a)) and np.all(np.isfinite(q))
            assert np.max(np.abs(a[:,5:7]))<=cfg.umax+1e-10
            assert q.min()>=0 and q.max()<=1 and np.all(np.diff(a[:,14])>=-1e-10)
            assert protocol['wind_sha256']==hashlib.sha256((site/f'data/scenario{scenario}/stationary-velocity.f32').read_bytes()).hexdigest()
            replay=jax.jit(jax.vmap(lambda state,clarity,u,alive:m.advance(state,clarity,u,truth,env,cfg,alive,interval=cfg.execution_dt)))
            end=replay(jnp.asarray(x[:-1]),jnp.asarray(q[:-1]),jnp.asarray(a[1:,5:7]),jnp.asarray(a[:-1,18]>0))
            # The saved row records the command applied during the preceding
            # interval. All intervals, including post-contact decay, are tested.
            state_error=float(np.max(np.abs(np.asarray(end[0])-x[1:])))
            clarity_error=float(np.max(np.abs(np.asarray(end[1])-q[1:])))
            cost_error=float(np.max(np.abs(np.cumsum(np.asarray(end[3]))-a[1:,14])))
            assert state_error<1e-10 and clarity_error<1e-10 and cost_error<1e-9
            fine_cfg=replace(cfg,physics_dt=.005)
            fine=jax.jit(jax.vmap(lambda state,clarity,u,alive:m.advance(state,clarity,u,truth,env,fine_cfg,alive,interval=cfg.execution_dt)))
            refined=fine(jnp.asarray(x[:-1]),jnp.asarray(q[:-1]),jnp.asarray(a[1:,5:7]),jnp.asarray(a[:-1,18]>0))
            # Local held-control numerical sensitivity, not a reoptimized run.
            local_position_difference=float(np.max(np.linalg.norm(np.asarray(refined[0])[:,:2]-x[1:,:2],axis=1)))
            local_clarity_difference=float(np.max(np.abs(np.asarray(refined[1])-q[1:])))
            targets=np.asarray(env.targets)
            deficit=np.maximum(targets-q,0).mean(axis=1)
            np.testing.assert_allclose(deficit,a[:,13],atol=1e-12)
            for i in range(2):np.testing.assert_allclose(q[:,grid['membership'][:,i]].mean(axis=1),a[:,15+i],atol=1e-12)
            noise=np.random.default_rng(protocol['seed']).normal(size=(round(cfg.mission_seconds/cfg.dt)+1,2))
            expected=np.asarray(truth.at(obs[:,1:3]))+cfg.observation_std*noise[np.rint(obs[:,0]/cfg.dt).astype(int)] if len(obs) else np.zeros((0,2))
            np.testing.assert_allclose(obs[:,3:5],expected,atol=1e-12)
            for plan in record['plans']:
                assert plan['evaluations']==cfg.diffusion_steps*cfg.proposals+2+10
                assert len(plan['predicted_states'])==(cfg.worlds if method=='aware' else 1)
            forecast_checks=audit_selected_plans(directory,ident,record,cfg,env)
            rows.append(dict(id=ident,seconds=float(a[-1,0]),max_state_replay_error=state_error,
                max_clarity_replay_error=clarity_error,max_cost_replay_error=cost_error,
                max_local_position_refinement_m=local_position_difference,max_local_clarity_refinement=local_clarity_difference,
                observations=len(obs),plans=len(record['plans']),selected_forecast_replays=forecast_checks,summary=record['summary']))
        if len(protocols)==2:
            assert protocols[0]['settings']==protocols[1]['settings']
            assert protocols[0]['wind_sha256']==protocols[1]['wind_sha256']
            assert protocols[0]['seed']==protocols[1]['seed']
    report=dict(checks='All exported intervals replayed from stored controls; independent paired-input, cost, region clarity and measurement checks.',
        refinement_scope='Local held-control .01 to .005 s integration check, starting at each saved state. This is not a reoptimized or re-filtered mission.',runs=rows)
    (directory/('audit-partial.json' if only else 'audit.json')).write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--directory',type=Path,required=True);p.add_argument('--site',type=Path,default=m.physical.SITE)
    p.add_argument('--only',nargs='+')
    args=p.parse_args();audit(args.directory,args.site,args.only)
